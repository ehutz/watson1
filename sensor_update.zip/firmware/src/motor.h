/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _MOTOR_H    /* Guard against multiple inclusion */
#define _MOTOR_H

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */
#include "system/ports/sys_ports.h"
#include "FreeRTOS.h"
#include "queue.h"
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Constants                                                         */
/* ************************************************************************** */
/* ************************************************************************** */

#define MOTOR_STOP      's'
#define MOTOR_FORWARD   'f'
#define MOTOR_BACKWARD  'b'
#define MOTOR_LEFT      'l'
#define MOTOR_RIGHT     'r'
QueueHandle_t receiveQueue;
QueueHandle_t transmitQueue;
QueueHandle_t motorQueue;

// *****************************************************************************
// *****************************************************************************
// Section: Data Types
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Interface Functions
// *****************************************************************************
// *****************************************************************************
void Motor_Init();
void Motor_Left();
void Motor_Right();
void Motor_Forward();
void Motor_Backward();
void Motor_Stop();
typedef enum {forward, backward, left, right, stop} MOVEMENT;

void changeDirection(char direction);


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
