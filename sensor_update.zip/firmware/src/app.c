//this one is madelyn's being used for integration
#include "FreeRTOS.h"
#include "app.h"
#include "jsonparser.h"

void getCommand(char *cmd, value *cmdType)
{
    parse(receiveQueue, cmd, cmdType);
    //DRV_USART0_WriteByte(temp);
    return;
};

void APP_Initialize ( void )
{
    // Initialize ports for the motor control
    Motor_Init();
  
    appData.state = APP_STATE_INIT;
    /* Place the App state machine in its initial state. */
    
    // Initial state for motor state machine 
    Move = stop;
    
    // Initialize queues
    motorQueue = xQueueCreate(30, sizeof(unsigned int));
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    transmitQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    count_timer_5 = 0;
    count = 0;
    count2 = 0;
    count3 = 0;
    sense = 0;
    c = 0;
    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('N');    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('T');    
    // Gives a starting point in DigiView
    dbgOutputLoc(0xFF);
    
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_A, 3 );
}

void APP_Tasks ( void ){
    char prevMotor = '0';
    toMotor = '0';
    char toMotorQueue = '0';
    char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;

    switch ( appData.state ){
        case APP_STATE_INIT:{            
        
            // START TIMER 2
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
            DRV_TMR0_Start();
            // TIMER 2
            
            // START TIMER 3
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
            DRV_TMR1_Start();
            // TIMER 3
            
            // START TIMER 4
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
            DRV_TMR2_Start();
            // TIMER 4
            
            // START TIMER 5
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_5);
            DRV_TMR3_Start();
            // TIMER 5
                        
            DRV_USART0_WriteByte('I');    
            DRV_USART0_WriteByte('D');    
            DRV_USART0_WriteByte('L');    
            DRV_USART0_WriteByte('E');    
            appData.state = APP_STATE_IDLE;
            
            break;
         }
        case APP_STATE_IDLE:{   
            //*********//This is just temporary for random sensing until game logic is  done
            if(sense) c=0;
            if(count2 > 1000){
                count3++;
                count2 = 0;
                if(count3 > 10){
                    count3 = 0;
                    sense = 1;
                }
            }
            else
                count2++;
            //*************//
            switch(SENSE)
            {
                case out:
                {
                    if(sense){
                        TRISE = 0x0300; //set pins RE0 to RE7 to 0: output
                        LATE = 0x00FF;
                        SENSE = in;
                        count = 0;
                        count_timer_5 = 0;
                    }
                    break;
                }
                case in:
                {
                    if(count_timer_5 > 1){
                        TRISE = 0x3FF; //set pins RE0 to RE7 to 1: input
                        LATE = 0x0000; //value sent to pins is zero, let them decay
                        if(PORTE & 0xFF)
                                count = count_timer_5;
                        else
                            SENSE = stopped;
                        DRV_USART0_WriteByte(count);
                    }
                    break;
                }
                case stopped:
                {
                    if(count < 90){ //white
                        //toMotor = MOTOR_BACKWARD;
                        if(c < 1){
                            DRV_USART0_WriteByte('W');
                        }
                        else
                            c++;
                    }
                    else {//black
                        //toMotor = MOTOR_LEFT;
                        if(c < 1){
                            DRV_USART0_WriteByte('B');
                        }
                        else
                            c++;
                    }
                    sense = 0;
                    SENSE = out;  
                    break;
                }
            }
            
            if(!DRV_USART0_ReceiverBufferIsEmpty())
            {
                dbgOutputLoc(UART_RECEIVE_BUFFER_NOT_EMPTY);
                data = DRV_USART0_ReadByte();
             //   DRV_USART0_WriteByte(data);
                if(data == '{'){
                    charIsJunk = false;
                }
                if (!charIsJunk){
                    xQueueSendToBack(receiveQueue, &data, portMAX_DELAY);
                }
                if (data == '}'){
                    charIsJunk = true;
                }
            }
            dbgOutputLoc(AFTER_UART_RECEIVE_BUFFER_NOT_EMPTY);
            
            //if the motor has a command to change, pop the char command to toMotor.
            if(!xQueueIsQueueEmptyFromISR(motorQueue)){
                dbgOutputLoc(MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            }
            dbgOutputLoc(AFTER_MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
            
            //if the JSON message is completed, parse it.
            if(data == '}'){ //end of a JSON command
                dbgOutputLoc(ENTERED_DATA_EQUALS_IF);
                char cmd;
                value cmdType;
                getCommand(&cmd, &cmdType);
                //if this is a motor command, ad a message to the motor queue
                if (cmdType == DIRECTION) {
                    toMotorQueue = cmd;
                    xQueueSendToBack(motorQueue, &toMotorQueue, portMAX_DELAY);                
                }
                else if (cmdType == BAD){
                    sendGeneralMessage("error",5,"bad JSON",8,transmitQueue);
                }
                else if (cmdType == PING){
                    sendGeneralMessage("ping",4,"pong",4,transmitQueue);
                }
                else if (cmdType == MODE){
                    sendGeneralMessage("mode",4,"set",3,transmitQueue);
                }
                else {
                    sendGeneralMessage("error",5,"missing",7,transmitQueue);
                }
            }
            dbgOutputLoc(AFTER_DATA_EQUALS_IF);
                
            if(prevMotor != toMotor){
                dbgOutputLoc(ENTERED_PREV_NOT_EQUALS_MOTOR);
                //DRV_USART0_WriteByte(Move);              
                changeDirection(toMotor);
                prevMotor = toMotor;
            }
        }
    }
}

//Timer2 is internal, period of 20us
void __ISR(_TIMER_2_VECTOR, ipl6auto) _IntHandlerDrvTmrInstance0( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2) )
    {
        dbgOutputLoc(ISR_TIMER_2_ENTERED);
        count_timer_2++;
        DRV_OC0_PulseWidthSet(0);
        DRV_OC1_PulseWidthSet(0);
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
        dbgOutputLoc(count_timer_2);
        dbgOutputLoc(ISR_TIMER_2_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 3 is externally sourced, period of 1.6ms
void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3) )
    {
        dbgOutputLoc(ISR_TIMER_3_ENTERED);
        count_timer_3++;
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
        dbgOutputLoc(count_timer_3);
        dbgOutputLoc(ISR_TIMER_3_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

//Timer 4 is externally sourced, period of 1.6ms
void __ISR(_TIMER_4_VECTOR, ipl5auto) _IntHandlerDrvTmrInstance2( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4) )
    {
        dbgOutputLoc(ISR_TIMER_4_ENTERED);
        count_timer_4++;
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
        dbgOutputLoc(count_timer_4);
        dbgOutputLoc(ISR_TIMER_4_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 5 is internal, period of 10us
void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        dbgOutputLoc(ISR_TIMER_5_ENTERED);
        count_timer_5++;
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
        dbgOutputLoc(count_timer_5);
        dbgOutputLoc(ISR_TIMER_5_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}