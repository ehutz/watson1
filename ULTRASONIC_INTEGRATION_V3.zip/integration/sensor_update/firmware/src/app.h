#ifndef _APP_H
#define _APP_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "system_config.h"
#include "system_definitions.h"
#include "driver/tmr/drv_tmr.h"
#include "driver/spi/drv_spi.h"
#include "system/ports/sys_ports.h"
#include "system/int/sys_int.h"
#include "task.h"
#include "timers.h"
#include "queue.h"

// These #includes are headers written by Team5
#include "debug.h"
#include "motor.h"
#include "jsonparser.h"
#include "messages.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END 

// *****************************************************************************
/* Application states

  Summary:
    Application states enumeration

  Description:
    This enumeration defines the valid application states.  These states
    determine the behavior of the application at various times.
*/
#define SERVER_PING 'p'
#define MODE_GAME 'g'
#define MODE_DEBUG 'd'
#define MODE_TEST 't'
#define MODE_CALIBRATE 'c'

typedef enum
{
	/* Application's state machine's initial state. */
	APP_STATE_INIT=0,
    APP_STATE_IDLE, 
	APP_STATE_SERVICE_TASKS,
	/* TODO: Define states used by the application state machine. */

} APP_STATES;

enum {in, out, stopped} SENSE;
// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct
{
    /* The application's current state */
    APP_STATES state;

} APP_DATA;

DRV_HANDLE  timer3;

APP_DATA appData;
MOVEMENT Move;
bool charIsJunk;

int count;
int c;
int count2;
int count3;
int count5;
int sense;
char toMotor;
int count_timer_2;
int count_timer_3;
int count_timer_4;
int count_timer_5;

// Start: Variables for ultrasonic sensor
int count_ultrasonic;
int US_distance; // Distance in centimeters that ultrasonic sensor is sensing
int pulse_start; // us
int pulse_end; // us
bool flag; // Used in timer 5 ISR to determine if Echo line on ultrasonic sensor is high or low
bool echo_done;
bool ultrasonic_flag;
// End: Variables for ultrasonic sensor

//void getCommand(char * cmd, value * cmdType);

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Routines
// *****************************************************************************
// *****************************************************************************
/* These routines are called by drivers when certain events occur.
*/
	
// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Summary:
     MPLAB Harmony application initialization routine.

  Description:
    This function initializes the Harmony application.  It places the 
    application in its initial state and prepares it to run so that its 
    APP_Tasks function can be called.

  Precondition:
    All other system initialization routines should be called before calling
    this routine (in "SYS_Initialize").

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Initialize();
    </code>

  Remarks:
    This routine must be called from the SYS_Initialize function.
*/

void APP_Initialize ( void );


/*******************************************************************************
  Function:
    void APP_Tasks ( void )

  Summary:
    MPLAB Harmony Demo application tasks function

  Description:
    This routine is the Harmony Demo application's tasks function.  It
    defines the application's state machine and core logic.

  Precondition:
    The system and application initialization ("SYS_Initialize") should be
    called before calling this.

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Tasks();
    </code>

  Remarks:
    This routine must be called from SYS_Tasks() routine.
 */

void APP_Tasks( void );


#endif /* _APP_H */

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

/*******************************************************************************
 End of File
 */

