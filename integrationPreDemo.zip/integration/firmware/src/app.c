#include "FreeRTOS.h"
#include "app.h"

int needToStop = 1;
int needToTurn = 0;
int needToClear = 1;
int needToWait = 0;
int isStraight = 1;

int xDifference = 0;
int yDifference = 0;
int blackCount = 0;
int whiteCount = 0;

int16_t RIGHT_PULSE_WIDTH = 1000;
int16_t LEFT_PULSE_WIDTH = 1000;

uint32_t timerThreeVal;
uint32_t timerFourVal;

// HEADING defined in app.h
HEADING currentFacing = EAST;
HEADING needToFace;

NAVIGATION_STATE navState = START;
NAVIGATION_STATE prevNavState;

int degreesToTurn = 0;

// initially 0, 0.
int curRowPos = 0;
int curColumnPos = 0;

int rowToGo = 0;
int columnToGo = 0;

//returns true if the sensor array reads all black
bool isHit()
{
	return false; //TODO: update with sensor array readings
}

// pass in currentFacing for current
int calculateTurn(HEADING current, HEADING next)
{
    if (current == next)
    {
        return 0;
    }
    else if ((current + next) % 2 == 0)
    {
        return 180;
    }
    else if ((current == (next + 1) % 4))
    {
        return 90;
    }
    else
    {
        // for this case, perform a left turn of 90 degrees instead.
        return -90;
    }
}

/*

void navigateToX()
{
    if (curRowPos == rowToGo)
    {
        // already in the correct row.
        degreesToTurn = 0;
        needToFace = currentFacing;
        //toMotor = MOTOR_STOP;

        return;
    }
    else
    {
        // Determine if we need to do a left or right turn.
        if (rowToGo > curRowPos)
        {
            // need to face SOUTH.
            degreesToTurn = calculateTurn(currentFacing, SOUTH);
            needToFace = SOUTH;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else if (degreesToTurn == 90 || degreesToTurn == 180)
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
        else
        {
            // need to face NORTH.
            degreesToTurn = calculateTurn(currentFacing, NORTH);
            needToFace = NORTH;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else if (degreesToTurn == 90 || degreesToTurn == 180)
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
    }
}

void navigateToY()
{
    if (curColumnPos == columnToGo)
    {
        // already in the correct column.
        degreesToTurn = 0;
        needToFace = currentFacing;
        toMotor = MOTOR_STOP;
 
        return;
    }
    else
    {
        // Determine if we need to do a left or right turn.
        if (columnToGo > curColumnPos)
        {
            // need to face EAST.
            degreesToTurn = calculateTurn(currentFacing, EAST);
            needToFace = EAST;
            needToClear = 1;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else if (degreesToTurn == 90 || degreesToTurn == 180)
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
        else
        {
            // need to face WEST.
            degreesToTurn = calculateTurn(currentFacing, WEST);
            needToFace = WEST;
            needToClear = 1;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else if (degreesToTurn == 90 || degreesToTurn == 180)
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
    }
}

void navigateToCoordinate()
{
    //navigateToX(rowToGo);
    navigateToY(columnToGo);
}
*/

void getCommand(char *cmd, value *cmdType)
{
    parse(receiveQueue, cmd, cmdType);
    return;
};


bool goToCoordinate(char cmd)
{
    /*

     * Get the rover's current coordinates.
     * Get the rover's current "direction" aka which way it's facing.
     * Calculate how far we need to go vertically.
     * Calculate how far we need to go horizontally.
     * Use the reflectance sensor to determine the number of squares we have crossed (black stripe count).
     * Keep moving until we get to the desired coordinate.
     
     */
    columnToGo = cmd & 0xF;
    rowToGo = (cmd >> 4) - 3;
    char output[] = {rowToGo, ',', columnToGo};
    bool hit = false;

    //navigateToCoordinate();

    //TODO: flag the motors to start moving
    //TODO: flag hit / miss logic
    
    /*
    if (hit || row == 0x32)
    {
        sendGeneralMessage("hit", 3, output, 3, transmitQueue);    
        return true;
    }
    else
    {
        sendGeneralMessage("miss", 4, output, 3, transmitQueue);    
    }
    */

    return hit;
}

void getDistanceReading() 
{
    SYS_PORTS_Write( PORTS_ID_0, PORT_CHANNEL_A, (1 << 8) << 8);
    int distance = 0;
    char returnValue = 0x0;
    SYS_PORTS_Write( PORTS_ID_0, PORT_CHANNEL_A, 0x0 << 8);
    while (distance < 350) 
    {
        distance++;
    }

    readPort(&returnValue);
    while (returnValue < 0x200 && distance < 10000) 
    {
        readPort(&returnValue);
        distance++;
    }
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    char *x;
   // int size = asprintf(&x, "%i", distance);
   // DRV_USART0_WriteByte('o');    
   // if(size == -1){
   //     sendErrorMessage("distance", 8);
   // }
   // else{
        sendGeneralMessage("distance", 8, "far", 3, transmitQueue);
   // }
   // free(x);
}

void APP_Initialize ( void )
{
    // Initialize ports for the motor control
    Motor_Init();
  
    lastSentMessage[0] = '\0';
    appData.clientName = DEFAULT_NAME;
    appData.clientMode = DEBUG;
    appData.isActiveClient = false;
    appData.state = APP_STATE_INIT;
    /* Place the App state machine in its initial state. */
    appData.hits_to_win = 3;
    // Initial state for motor state machine 
    Move = stop;
    
    // Initialize queues
    motorQueue = xQueueCreate(30, sizeof(unsigned int));
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    transmitQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    count_timer_5 = 0;
    count = 0;
    count2 = 0;
    count3 = 0;
    sense = 1;
    c = 0;
    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('N');    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('T');    
    // Gives a starting point in DigiView
    dbgOutputLoc(0xFF);
    
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_A, 3 );
}

void APP_Tasks ( void )
{
    char prevMotor = '0';
    char prevCmd = '0';
    toMotor = '0';
    char toMotorQueue = '0';
    char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;

    switch ( appData.state )
    {
        case APP_STATE_INIT:
        {            
        
            // START TIMER 2
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
            DRV_TMR0_Start();
            // TIMER 2
            
            // START TIMER 3
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
            DRV_TMR1_Start();
            // TIMER 3
            
            // START TIMER 4
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
            DRV_TMR2_Start();
            // TIMER 4
            
            // START TIMER 5
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_5);
            DRV_TMR3_Start();
            // TIMER 5
                        
            DRV_USART0_WriteByte('I');    
            DRV_USART0_WriteByte('D');    
            DRV_USART0_WriteByte('L');    
            DRV_USART0_WriteByte('E');    
            appData.state = APP_STATE_IDLE;
            appData.clientName = DEFAULT_NAME;
            appData.hits_to_win = 3;
            appData.isGameOver = false;
            appData.isWinner = false;
            
            break;
         }
        case APP_STATE_IDLE:
        {   

            char cmd;
            value cmdType;
            if(!DRV_USART0_ReceiverBufferIsEmpty())
            {
                dbgOutputLoc(UART_RECEIVE_BUFFER_NOT_EMPTY);
                data = DRV_USART0_ReadByte();

                if(data == '{')
                {
                    charIsJunk = false;
                }
                if (!charIsJunk)
                {
                    xQueueSendToBack(receiveQueue, &data, portMAX_DELAY);
                }
                if (data == '}')
                {
                    charIsJunk = true;
                }
            }
            dbgOutputLoc(AFTER_UART_RECEIVE_BUFFER_NOT_EMPTY);
            
            //if the motor has a command to change, pop the char command to toMotor.
            if(!xQueueIsQueueEmptyFromISR(motorQueue)){
                dbgOutputLoc(MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            }
            dbgOutputLoc(AFTER_MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //if the JSON message is completed, parse it.
            if (data == '}')
            { //end of a JSON command
                dbgOutputLoc(ENTERED_DATA_EQUALS_IF);
                
                getCommand(&cmd, &cmdType);
                //if this is a motor command, ad a message to the motor queue
                if (cmdType == ACTIVE)
                {
                    if (cmd == appData.clientName) 
                    {
                        sendGeneralMessage("activated", 9, &appData.clientName, 1, transmitQueue);
                        appData.isActiveClient = true; 
                    }
                    else 
                    {
                        sendGeneralMessage("deact", 5, &appData.clientName, 1, transmitQueue);
                        appData.isActiveClient = false; 
                    }
                }
                else if (!appData.isActiveClient)
                {
                    //continue with what you were doing before.
           //         sendGeneralMessage("ghost",5,&appData.clientName,1,transmitQueue);
                }
                else if (cmdType == GAMEOVER || appData.isGameOver) 
                {
                    appData.isGameOver = true;
                    if (cmdType == GAMEOVER && cmd != appData.clientName)
                    {
                        appData.isWinner = false;
                    }
                    if(appData.isWinner)
                        sendGeneralMessage("WinScore",8,"3",1,transmitQueue);
                    else 
                    {
                        char score[1]= {((3 - appData.hits_to_win) & 0xF) + 0x30};
                        sendGeneralMessage("LossScore",9,score,1,transmitQueue);
                    }
                }
                else if (cmdType == PING)
                {
                    sendGeneralMessage("pong",4,&appData.clientName,1,transmitQueue);
                }
                else if (cmdType == DIRECTION) 
                {
                    toMotorQueue = cmd;
                    xQueueSendToBack(motorQueue, &toMotorQueue, portMAX_DELAY);                
                }
                else if (cmdType == BAD)
                {
                    sendGeneralMessage("error", 5,"bad JSON", 8,transmitQueue);
                }
                /*
                else if (cmdType == PING)
                {
                    sendGeneralMessage("ping", 4,"pong", 4, transmitQueue);
                }
                */
                else if (cmdType == MODE)
                {
                    appData.clientMode = cmd;
                    sendGeneralMessage("mode", 4, &cmd, 1, transmitQueue);
                }
                else if (cmdType == SETNAME)
                {
                    appData.clientName = cmd;
                    sendGeneralMessage("setname", 7, &cmd, 1, transmitQueue);
                }
                else if (cmdType == DISTANCE)
                {
                    getDistanceReading();
                }
                else if (cmdType == GOTO)
                {
                    //DRV_USART0_WriteByte('G');
                    //toMotor = MOTOR_FORWARD;
                    sendGeneralMessage("GOTO", 4, &cmd, 1, transmitQueue);

                    columnToGo = cmd & 0xF;
                    rowToGo = (cmd >> 4) - 3;
                    
                    // first, get to the right x-coordinate.
                    // from there, turn and move to the correct y-coordinate.

                    switch (navState)
                    {
                        case START:
                            
                            //DRV_USART0_WriteByte('S');

                            if (rowToGo != curRowPos)
                            {
                                xDifference = rowToGo - curRowPos;

                                if (rowToGo > curRowPos)
                                {
                                    // need to face SOUTH.
                                    degreesToTurn = calculateTurn(currentFacing, SOUTH);
                                    needToFace = SOUTH;
                                }
                                else
                                {
                                    // need to face NORTH.
                                    degreesToTurn = calculateTurn(currentFacing, NORTH);
                                    needToFace = NORTH;
                                }
                                navState = FACE_X;
                            }
                            else if (rowToGo == curRowPos)
                            {
                                xDifference = 0;
                                degreesToTurn = 0;
                                needToFace = currentFacing;
                                navState = PRE_FACE_Y;
                            }
                            break;

                        case FACE_X:
                            
                            //DRV_USART0_WriteByte('F');
                            //DRV_USART0_WriteByte('X');

                            if (degreesToTurn == -90)
                            {
                                // do a left turn of 90 degrees.
                                needToStop = 0;
                                needToTurn = 1;
                                needToClear = 1;
                                toMotor = MOTOR_LEFT;
                                //navState = MOVE_TO_X;
                            }
                            else if (degreesToTurn == 90 || degreesToTurn == 180)
                            {
                                // do a right turn of degreesToTurn
                                needToStop = 0;
                                needToTurn = 1;
                                needToClear = 1;
                                toMotor = MOTOR_RIGHT;
                                //navState = MOVE_TO_X;
                            }
                            
                            if (currentFacing == needToFace)
                            {
                                needToClear = 0;
                                toMotor = MOTOR_FORWARD;
                                navState = MOVE_TO_X;
                            }

                            break;
                        
                        case MOVE_TO_X:
                            
                            sense = 1;
                            //DRV_USART0_WriteByte('M');
                            //DRV_USART0_WriteByte('X');
                            
                            if (curRowPos != rowToGo)
                            {
                                
                                //DRV_USART0_WriteByte('B');
                                //DRV_USART0_WriteByte('C');
                                //DRV_USART0_WriteByte(blackCount);
                                
                                //DRV_USART0_WriteByte('X');
                                //DRV_USART0_WriteByte('P');
                                //DRV_USART0_WriteByte(curRowPos);
                                // rowToGo - curRowPos
                                if (xDifference > 0)
                                {
                                    sense = 1;
                                    // rowToGo > curRowPos
                                    // increment curRowPos
                                    if (blackCount >= 0)
                                    {
                                        // you crossed the black line.
                                        // should be on a white square.
                                        prevNavState = navState;
                                        navState = WHITE;
                                        curRowPos++;
                                        //blackCount = 0;
                                    }
                                }
                                else if (xDifference < 0)
                                {
                                    sense = 1;
                                    // curRowPos > rowToGo
                                    // decrement curRowPos
                                    if (blackCount >= 0)
                                    {
                                        prevNavState = navState;
                                        navState = WHITE;
                                        curRowPos--;
                                        //blackCount = 0;
                                    }
                                }
                            }
                            else
                            {
                                blackCount = 0;
                                whiteCount = 0;
                                sense = 0;
                                xDifference = 0;
                                needToStop = 1;
                                toMotor = MOTOR_STOP;
                                navState = PRE_FACE_Y;
                            }

                            break;
                            
                        case WHITE:
                             
                            DRV_USART0_WriteByte('W');
                            if (whiteCount > 0)
                            {
                                // should be on a white square.
                                // wait until you detect black again aka return to the previous state.
                                //whiteCount = 0;
                                if (xDifference > 0)
                                {
                                    curRowPos++;
                                }
                                else if (xDifference < 0)
                                {
                                    curRowPos--;
                                }
                                
                                if (yDifference > 0)
                                {
                                    curColumnPos++;
                                }
                                else if (yDifference < 0)
                                {
                                    curColumnPos--;
                                }

                                blackCount = 0;
                                navState = prevNavState;
                            }
                            
                            break;
                            
                        case PRE_FACE_Y:
                            
                            sense = 0;
                            blackCount = 0;
                            //toMotor = MOTOR_STOP;
                            //DRV_USART0_WriteByte('P');
                            //DRV_USART0_WriteByte('Y');

                            if (columnToGo != curColumnPos)
                            {
                                yDifference = columnToGo - curColumnPos;

                                if (columnToGo > curColumnPos)
                                {
                                    // need to face EAST.
                                    degreesToTurn = calculateTurn(currentFacing, EAST);
                                    needToFace = EAST;
                                }
                                else
                                {
                                    // need to face WEST.
                                    degreesToTurn = calculateTurn(currentFacing, WEST);
                                    needToFace = WEST;
                                }
                                navState = FACE_Y;
                            }
                            else if (columnToGo == curColumnPos)
                            {
                                yDifference = 0;
                                degreesToTurn = 0;
                                needToFace = currentFacing;
                                navState = REACHED_TARGET;
                            }
    
                            break;
                        
                        case FACE_Y:
                            
                            sense = 0;
                            blackCount = 0;
                            //DRV_USART0_WriteByte('F');
                            //DRV_USART0_WriteByte('Y');
                            
                            if (degreesToTurn == -90)
                            {
                                // do a left turn of 90 degrees.
                                needToStop = 0;
                                needToTurn = 1;
                                needToClear = 1;
                                toMotor = MOTOR_LEFT;
                                //navState = MOVE_TO_Y;
                            }
                            else if (degreesToTurn == 90 || degreesToTurn == 180)
                            {
                                // do a right turn of degreesToTurn
                                needToStop = 0;
                                needToTurn = 1;
                                needToClear = 1;
                                toMotor = MOTOR_RIGHT;
                                //navState = MOVE_TO_Y;
                            }
                            
                            if (currentFacing == needToFace)
                            {
                                needToClear = 0;
                                toMotor = MOTOR_FORWARD;
                                navState = MOVE_TO_Y;
                            }
 
                            break;
                            
                        case MOVE_TO_Y:
                            
                            sense = 1;
                            //DRV_USART0_WriteByte('M');
                            //DRV_USART0_WriteByte('Y');
                            
                            if (curColumnPos != columnToGo)
                            {
                                //DRV_USART0_WriteByte('B');
                                //DRV_USART0_WriteByte('C');
                                //DRV_USART0_WriteByte(blackCount);
                                
                                //DRV_USART0_WriteByte('X');
                                //DRV_USART0_WriteByte('C');
                                //DRV_USART0_WriteByte(curColumnPos);
                                
                                
                                
                                // columnToGo - curColumnPos
                                if (yDifference > 0)
                                {
                                    sense = 1;
                                    // columnToGo > curColumnPos
                                    // increment curColumnPos

                                    if (blackCount >= 0)
                                    {
                                        // you crossed the black line.
                                        // should be on a white square.
                                        prevNavState = navState;
                                        navState = WHITE;
                                        curColumnPos++;
                                        //blackCount = 0;
                                    }
                                }
                                else if (yDifference < 0)
                                {
                                    sense = 1;
                                    // curColumnPos > columnToGo
                                    // decrement curColumnPos
                                    if (blackCount >= 0)
                                    {
                                        // you crossed the black line.
                                        // should be on a white square.
                                        prevNavState = navState;
                                        navState = WHITE;
                                        curColumnPos--;
                                        //blackCount = 0;
                                    }
                                }
                            }
                            else
                            {
                                sense = 0;
                                blackCount = 0;
                                whiteCount = 0;
                                yDifference = 0;
                                needToStop = 1;
                                toMotor = MOTOR_STOP;
                                navState = REACHED_TARGET;
                            }
  
                            break;
                            
                        case REACHED_TARGET:
                            
                            DRV_USART0_WriteByte('T');

                            sense = 0;
                            xDifference = 0;
                            yDifference = 0;
                            navState = START;

                            break;
                    }
 
                    /*
                    if (goToCoordinate(cmd)) 
                    {
                        appData.hits_to_win = appData.hits_to_win - 1;
                    }
                    if(appData.hits_to_win == 0) 
                    {
                        sendGeneralMessage("WIN", 3, &appData.clientName,1, transmitQueue);
                        appData.isGameOver = true;
                        appData.isWinner = true;
                    }
                    */
                }
                else
                {
                    sendGeneralMessage("error", 5, "missing", 7, transmitQueue);
                }
            }
            dbgOutputLoc(AFTER_DATA_EQUALS_IF);

            if (prevMotor != toMotor)
            {

                if (toMotor == MOTOR_STOP)
                {
                    needToStop = 1;
                    DRV_TMR1_CounterClear();
                    DRV_TMR2_CounterClear();
                }
                else
                {
                    needToStop = 0;
                }

                if (toMotor == MOTOR_RIGHT || toMotor == MOTOR_LEFT)
                {
                    needToTurn = 1;

                    if (needToClear == 1)
                    {
                        DRV_TMR1_CounterClear();
                        DRV_TMR2_CounterClear();

                        // 1250
                        // 1300

                        LEFT_PULSE_WIDTH = 1300;
                        RIGHT_PULSE_WIDTH = 1300;

                        DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                        DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);

                        needToClear = 0;
                    }
                }
                else if (toMotor == MOTOR_FORWARD || toMotor == MOTOR_BACKWARD)
                {
                    needToTurn = 0;
                    if (needToClear == 0)
                    {
                        DRV_TMR1_CounterClear();
                        DRV_TMR2_CounterClear();

                        LEFT_PULSE_WIDTH = 1000;
                        RIGHT_PULSE_WIDTH = 1000;

                        needToClear = 1;
                    }
                }
                dbgOutputLoc(ENTERED_PREV_NOT_EQUALS_MOTOR);

                changeDirection(toMotor);
                prevMotor = toMotor;
            }
        }
    }
}

//Timer2 is internal, period of 20us
void __ISR(_TIMER_2_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance0(void)
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2))
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_ENTERED);

        count_timer_2++;

        if (needToStop == 1)
        {
            DRV_OC0_PulseWidthSet(0);
            DRV_OC1_PulseWidthSet(0);
        }
        else
        {
            if (needToTurn == 0)
            {

                DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);

                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT

                if (timerThreeVal < timerFourVal)
                {
                    // the RIGHT motor is going faster. Speed up left motor.

                    float offset = timerFourVal - timerThreeVal;
                    LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH + (offset / timerThreeVal) * 100;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH - (offset / timerFourVal) * 100;
                }
                else if (timerThreeVal > timerFourVal)
                {
                    // the LEFT motor is going faster. Speed up right motor.

                    float offset = timerThreeVal - timerFourVal;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH + (offset / timerFourVal) * 180;
                    //LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH - (offset / timerThreeVal);

                }
            }
            else
            {
                // we want to turn.

                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT
                int leftStopped = 0;
                int rightStopped = 0;
                
                // 90 DEGREE TURN (RIGHT / LEFT)
                // 3
                // 4

                // 180 DEGREE TURN (LEFT)
                // 6
                // 6
                
                if (degreesToTurn == 90)
                {
                    // DO A RIGHT TURN OF 90 DEGREES.
                    if (timerThreeVal >= 3)
                    {
                        DRV_OC0_PulseWidthSet(0);
                        leftStopped = 1;
                    }
                    if (timerFourVal >= 4)
                    {
                        DRV_OC1_PulseWidthSet(0);
                        rightStopped = 1;
                    }
                    if (leftStopped == 1 && rightStopped == 1)
                    {
                        // turn has finished.
                        degreesToTurn = 0;
                        currentFacing = needToFace;
                    }
                }
                else if (degreesToTurn == 180)
                {
                    // DO A LEFT TURN OF 180 DEGREES.
                    if (timerThreeVal >= 6)
                    {
                        DRV_OC0_PulseWidthSet(0);
                        leftStopped = 1;
                    }
                    if (timerFourVal >= 6)
                    {
                        DRV_OC1_PulseWidthSet(0);
                        rightStopped = 1;
                    }
                    if (leftStopped == 1 && rightStopped == 1)
                    {
                        // turn has finished.
                        degreesToTurn = 0;
                        currentFacing = needToFace;
                    }
                }
                else if (degreesToTurn == -90)
                {
                    // DO A LEFT TURN OF 90 DEGREES.
                    if (timerThreeVal >= 3)
                    {
                        DRV_OC0_PulseWidthSet(0);
                        leftStopped = 1;
                    }
                    if (timerFourVal >= 4)
                    {
                        DRV_OC1_PulseWidthSet(0);
                        rightStopped = 1;
                    }
                    if (leftStopped == 1 && rightStopped == 1)
                    {
                        // turn has finished.
                        degreesToTurn = 0;
                        currentFacing = needToFace;
                    }
                }
            }
        }

        if (RIGHT_PULSE_WIDTH >= 1600 || LEFT_PULSE_WIDTH >= 1600)
        {
            // right = 1100;
            // left = 1200;
            RIGHT_PULSE_WIDTH = 1000;
            LEFT_PULSE_WIDTH = 1000;
        }

        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);

        // DEBUG
        dbgOutputLoc(count_timer_2);

        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 3 is externally sourced, period of 1.6ms
void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3) )
    {
        dbgOutputLoc(ISR_TIMER_3_ENTERED);
        count_timer_3++;
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
        dbgOutputLoc(count_timer_3);
        dbgOutputLoc(ISR_TIMER_3_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

//Timer 4 is externally sourced, period of 1.6ms
void __ISR(_TIMER_4_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance2( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4) )
    {
        dbgOutputLoc(ISR_TIMER_4_ENTERED);
        count_timer_4++;
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
        dbgOutputLoc(count_timer_4);
        dbgOutputLoc(ISR_TIMER_4_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 5 is internal, period of 10us
void __ISR(_TIMER_5_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if ( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        dbgOutputLoc(ISR_TIMER_5_ENTERED);
        count_timer_5++;
        
        if(sense == 1)
        {
            // c is there to limit the number of times the sensor spits out 'B'.
            c = 0;
        }
        
        if(count2 > 10000)
        {
            // count 2 and count 3 will generate sense = 1 ~ 10 times a second.
           count3++;
           count2 = 0;
           if(count3 > 10)
           {
                count3 = 0;
                sense = 1;
           }
        }
        else
        {
            count2++;
        }

            //*************//
            switch(SENSE)
            {
                case out:
                {
                    if(sense == 1)
                    {
                        // set the sensor to output mode.
                        TRISE = 0x0300; //set pins RE0 to RE7 to 0: output
                        LATE = 0x00FF;
                        SENSE = in;
                        count = 0; // reset counts to have accurate decay.
                        count_timer_5 = 0;
                    }
                    break;
                }
                case in:
                {
                    if(count_timer_5 > 1)
                    {
                        // set it back to input mode and let it decay.
                        TRISE = 0x3FF; //set pins RE0 to RE7 to 1: input
                        LATE = 0x0000; //value sent to pins is zero, let them decay
                        if (PORTE & 0xFF)
                        {
                            // when it decays, track how much time it took.
                            count = count_timer_5;
                        }
                        else
                            SENSE = stopped;
                        //DRV_USART0_WriteByte(count);
                    }
                    break;
                }
                case stopped:
                {
                    // Based on how much time it took to decay, the sensor reading will either be black or white.
                    if(count < 90)
                    { //white
                        //toMotor = MOTOR_BACKWARD;
                        if(c < 1)
                        {
                            whiteCount++;
                            //blackCount = 0;
                        }
                        else
                            c++;
                    }
                    else 
                    {//black
                        //toMotor = MOTOR_LEFT;
                        if(c < 1)
                        {
                            blackCount++;
                        }
                        else
                            c++;
                    }
                    sense = 0;
                    SENSE = out;  
                    break;
                }
            }

        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
        dbgOutputLoc(count_timer_5);
        dbgOutputLoc(ISR_TIMER_5_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}
