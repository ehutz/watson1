#include "jsonparser.h"

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */
/** Descriptive Data Item Name

  @Summary
    Brief one-line summary of the data item.
    
  @Description
    Full description, explaining the purpose and usage of data item.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
  @Remarks
    Any additional remarks
 */
int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */

/** 
  @Function
    int ExampleLocalFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Description
    Full description, explaining the purpose and usage of the function.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

  @Precondition
    List and describe any required preconditions. If there are no preconditions,
    enter "None."

  @Parameters
    @param param1 Describe the first parameter to the function.
    
    @param param2 Describe the second parameter to the function.

  @Returns
    List (if feasible) and describe the return values of the function.
    <ul>
      <li>1   Indicates an error occurred
      <li>0   Indicates an error did not occur
    </ul>

  @Remarks
    Describe any special behavior not described above.
    <p>
    Any additional remarks.

  @Example
    @code
    if(ExampleFunctionName(1, 2) == 0)
    {
        return 3;
    }
 */
static int ExampleLocalFunction(int param1, int param2) {
    return 0;
}


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    int ExampleInterfaceFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Remarks
    Refer to the example_file.h interface header for function usage details.
 */
char parse(QueueHandle_t rQueue) 
{
    char jsonChar = '0';
    char mode[10];
    int i = 0;
    char dir = 's';
    state = OPEN_CURLY;
    while(!xQueueIsQueueEmptyFromISR(rQueue))
    {
        xQueueReceive(rQueue, &jsonChar, portMAX_DELAY);
        if(jsonChar == '}'){
            return dir;
        }
        switch(state)
        {
            case OPEN_CURLY:
                if(jsonChar == '{')
                {
                    state = OPEN_QUOTE;
                }
                break;
            case OPEN_QUOTE:
                if(jsonChar == '"')
                {
                    state = MODE;
                }
                break;
            case MODE:
                while(jsonChar != '"' && i < 10)
                {
                    mode[i] = jsonChar;
                    i++;
                }
                i = 0;
                state = COLON;
                break; 
            case COLON:
                if(jsonChar == ':')
                {
                    state = DIRECTION;
                }
                break;
            case DIRECTION:    
                if(jsonChar == STOP)
                {
                    dir = 's';
                }
                else if(jsonChar == FORWARD)
                {
                    dir = 'f';
                }
                else if(jsonChar == BACKWARD)
                {
                    dir = 'b';
                }
                else if(jsonChar == LEFT)
                {
                    dir = 'l';
                }
                else if(jsonChar == RIGHT)
                {
                    dir = 'r';
                }
                state = CLOSE_CURLY;
                break;
            case CLOSE_CURLY:
                if(jsonChar == '}')
                {
                    return dir;
                }
                break;
            default:
                // TODO: DEBUG - Print out character
                break;
        }
    }
}


/* *****************************************************************************
 End of File
 */
