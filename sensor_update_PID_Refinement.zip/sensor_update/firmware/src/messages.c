/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */
#include "messages.h"


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */



/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*******************************************************************************
  Function:
    void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'd', 'i', 'r' ,'"', ':','"' };
    unsigned int header_length = 8;
    
    char footer[] = {'"', '}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'p', 'i', 'n' ,'g','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'm', 'o', 'd' ,'e','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendErrorMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendErrorMessage(char out[], unsigned int length)
{
    char header[] = { '{', '"', 'E', 'R', 'R' ,'O','R','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

void sendGeneralMessage(char cmd[], unsigned int cmdLen,char msg[], 
        unsigned int msgLen, QueueHandle_t tQueue){
    DRV_USART0_WriteByte('{');            
    DRV_USART0_WriteByte('"');            
    int i = 0;
    while (i < cmdLen)
    {
        DRV_USART0_WriteByte(cmd[i]);            
        i++;
    }
    DRV_USART0_WriteByte('"');            
    DRV_USART0_WriteByte(':');            
    DRV_USART0_WriteByte('"');            
    
    i = 0;
    while (i < msgLen)
    {
        DRV_USART0_WriteByte(msg[i]);            
        i++;
    }
    DRV_USART0_WriteByte('"');            
    DRV_USART0_WriteByte('}');            
    
}


/* *****************************************************************************
 End of File
 */
