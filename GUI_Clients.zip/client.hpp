#ifndef CLIENT_1_HPP
#define CLIENT_1_HPP

#include <QWidget>

class QLineEdit;
class QLabel;
class QTableWidget;
class QTcpSocket;
class QGridLayout;

class Client: public QWidget {
Q_OBJECT
public:
  Client(QWidget * parent = nullptr);

  Client(int client_number, QWidget * parent = nullptr);

public slots:
  void hitOrMissShip(int x, int y);

private:
  QLineEdit * title_bar_client;
  QLabel * title_label_client;
  QTableWidget * client_grid;
  QTcpSocket * client;
  QGridLayout * layout;

  int client_id;
  bool cell_clicked[25];

  QString numToLetter(int x);
};
#endif
