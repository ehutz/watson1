#include "client.hpp"
#include <QApplication>

int main(int argc, char* argv[]) {
  QApplication app(argc, argv);

  Client client1(1);
  client1.show();

  Client client2(2);
  client2.show();

  return app.exec();
}
