#include "client.hpp"
#include <QLayout>
#include <QLineEdit>
#include <QLabel>
#include <QTableWidget>
#include <QTableView>
#include <QStringList>
#include <QString>
#include <QTcpSocket>
#include <QDebug>

unsigned int turn_count = 0;

Client::Client(QWidget * parent) {}

Client::Client(int client_number, QWidget * parent)
{
  client_id = client_number;

  const int timeout = 10 * 1000;
  client = new QTcpSocket;
  client->connectToHost("192.168.1.100", 2000); //parameters are server name, server port
  if (!client->waitForConnected(timeout)) {
      qDebug() << "Client " << QString::number(client_number) << " could not connect to server.";
  }
  client->setReadBufferSize(1024); // Setting this to 0 allows all incoming data to be buffered

  QStringList table_row_labels;
  table_row_labels << "A" << "B" << "C" << "D" << "E";

  title_bar_client = new QLineEdit;
  title_bar_client->setReadOnly(true);
  QString title;
  title = "Client " + QString::number(client_number);
  title_label_client = new QLabel(title);

  client_grid = new QTableWidget(5,5);
  client_grid->setFixedSize(520,524);
  client_grid->setVerticalHeaderLabels(table_row_labels);
  for(int i = 0; i < 5; i++)
    client_grid->setRowHeight(i,100);

  for(int i = 0; i < 5; i++)
  {
    for(int j = 0; j < 5; j++)
    {
      // Initialize
      client_grid->setItem(i, j, new QTableWidgetItem);
      cell_clicked[i+j*5] = false;
    }
  }

  QObject::connect(client_grid, SIGNAL(cellClicked(int, int)), this, SLOT(hitOrMissShip(int, int)));

  layout = new QGridLayout;
  layout->addWidget(title_bar_client, 0, 0);
  layout->addWidget(title_label_client, 0, 0);
  layout->addWidget(client_grid, 1,0);
  this->setLayout(layout);

  // Ping the server
  client->write("HELLO!");
}

void Client::hitOrMissShip(int x, int y)
{
  QString x_coord, y_coord;
  QString message_to_server;
  char * message_to_server_char;
  char * ping_from_server;
  char * message_from_server;

  x_coord = numToLetter(x);
  y_coord = QString::number(y+1);

  if( cell_clicked[x+y*5] ) // If the user already clicked a cell..
  {
    title_label_client->setText(QString("Client " + QString::number(client_id) + ": You already clicked cell " +
                                x_coord + y_coord));
  }
  else if( (turn_count+client_id) % 2 != 0 )
  {
    turn_count++;
    title_label_client->setText(QString("Client " + QString::number(client_id)));

    // Read PING from server
    //if(client->waitForReadyRead(3*1000)) // TODO: Update based on how long it takes the rover to navigate
    //{
      client->read(ping_from_server, 100);
      qDebug() << ping_from_server;
    //}

    // Send coordinate clicked by user to server
    message_to_server = "{\"coordinate\":" + x_coord + y_coord + "}";
    message_to_server_char = new char[message_to_server.length()+1];
    strcpy(message_to_server_char, message_to_server.toLatin1().constData());
    client->write(message_to_server_char);
    cell_clicked[x+y*5] = true;
    qDebug() << "Sent coordinates";

    // Read hit, miss, or win from server
    if(client->waitForReadyRead(3*1000)) // TODO: Update based on how long it takes the rover to navigate
    {
      client->read(message_from_server, 100);
      qDebug() << message_from_server;
    }
    client->write("OK");
    if(client->waitForReadyRead(3*1000)) // TODO: Update based on how long it takes the rover to navigate
    {
      client->read(message_from_server, 100);
      qDebug() << message_from_server;
    }
    client->write("OK");

    // Update GUI with red for hit and gray for miss
    if( QString(message_from_server).contains(QString("hit")) )
      client_grid->item(x, y)->setBackground(Qt::red);
    else if( QString(message_from_server).contains(QString("miss")) )
      client_grid->item(x, y)->setBackground(Qt::gray);
    if( QString(message_from_server).contains(QString("\"win\":1")) )
    {
      if(client_id == 1)
      {
        client_grid->item(x, y)->setBackground(Qt::red);
        title_label_client->setText(QString("Client 1: WINNER!"));
      }
      else
        title_label_client->setText(QString("Client 2: LOSER"));
    }
    else if( QString(message_from_server).contains(QString("\"win\":2")) )
    {
      if(client_id == 2)
      {
        client_grid->item(x, y)->setBackground(Qt::red);
        title_label_client->setText(QString("Client 2: WINNER!"));
      }
      else
        title_label_client->setText(QString("Client 1: LOSER"));
    }

  }
  else
    title_label_client->setText(QString("Client " + QString::number(client_id)));

  client_grid->clearSelection();
}

QString Client::numToLetter(int x)
{
  QString letter = QString(QChar(0x41 + x));
  return letter;
}
