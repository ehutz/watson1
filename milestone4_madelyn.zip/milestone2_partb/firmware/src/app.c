/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************
#include "FreeRTOS.h"
#include "app.h"
#include "jsonparser.h"
// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    char getCommand ( void )
 *
char getCommand()
{
    char cmd = '0';
    value cmdType = PING;
    parse(receiveQueue, &cmd, &cmdType);
    //DRV_USART0_WriteByte(temp);
    return cmd;
}*/
void getCommand(char *cmd, value *cmdType)
{
    parse(receiveQueue, cmd, cmdType);
    //DRV_USART0_WriteByte(temp);
    return;
};
bool goToCoordinate(char cmd){
    char row = (cmd & 0xF) + 0x30;
    char column = (cmd >> 4) + 0x30;
    char output[] = {row, ',', column};
    bool hit = false;
    
    //TODO: flag the motors to start moving
    //TODO: flag hit/miss logic
    if (hit || row == 0x32) {
        sendGeneralMessage("hit",3, output, 3, transmitQueue);    
        return true;
    }
    else {
        sendGeneralMessage("miss",4, output, 3, transmitQueue);    
    }
    return hit;
}
void getDistanceReading(){
    SYS_PORTS_Write( PORTS_ID_0, PORT_CHANNEL_E, (1 << 8));
    int distance = 0;
    char returnValue = 0x0;
    SYS_PORTS_Write( PORTS_ID_0, PORT_CHANNEL_E, 0x0);
    while (distance < 350) {
        distance++;
    }

    readPort(&returnValue);
    while (returnValue < 0x200 && distance < 10000){
        readPort(&returnValue);
        distance++;
    }
    DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    DRV_USART0_WriteByte((distance % 10) + 0x30);    
    char *x;
   // int size = asprintf(&x, "%i", distance);
   // DRV_USART0_WriteByte('o');    
   // if(size == -1){
   //     sendErrorMessage("distance", 8);
   // }
   // else{
        sendGeneralMessage("distance", 8, "far", 3, transmitQueue);
   // }
   // free(x);
}
// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )
 */

void APP_Initialize ( void )
{
    // Initialize ports for the motor control
    Motor_Init();
    
    // Start the ADC
    DRV_ADC_Open();
    DRV_ADC_Start();
    lastSentMessage[0] = '\0';
    appData.clientName = DEFAULT_NAME;
    appData.clientMode = DEBUG;
    appData.isActiveClient = false;
    appData.state = APP_STATE_INIT;
    /* Place the App state machine in its initial state. */
    // Used to blink LED 4
    appData.heartbeatTimer = DRV_HANDLE_INVALID;
    appData.heartbeatCount = 0;
    appData.heartbeatToggle = false;
    appData.hits_to_win = 3;
        
    appData.ADCToggle = false;
    appData.ADCcount = 0;
    //Initial number of hits required to win the game
    
    // Initial state for motor state machine 
    Move = stop;
    
    // Initialize queues
    motorQueue = xQueueCreate(30, sizeof(unsigned int));
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    transmitQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    count_timer_5 = 0;
    // PING the server
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('N');    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('T');    
    // Gives a starting point in DigiView
    //dbgOutputLoc(0xFF);
    
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_A, 3 );
}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
void APP_Tasks ( void ){
    char prevMotor = '0';
    char prevCmd = '0';
    toMotor = '0';
    char toMotorQueue = '0';
    char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;
    
    // LED controls
    if (appData.heartbeatToggle == true){
        SYS_PORTS_PinToggle(PORTS_ID_0, APP_HEARTBEAT_PORT, APP_HEARTBEAT_PIN);
        appData.heartbeatToggle = false;
    }

    switch ( appData.state ){
        case APP_STATE_INIT:{            
            
            // START TIMER 2
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
            DRV_TMR0_Start();
            // TIMER 2
            
            // START TIMER 3
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
            DRV_TMR1_Start();
            // TIMER 3
            
            // START TIMER 4
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
            DRV_TMR2_Start();
            // TIMER 4
            
            // START TIMER 5
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_5);
            DRV_TMR3_Start();
            // TIMER 5
            
            // SPI
            SPIHandle = DRV_SPI_Open(DRV_SPI_INDEX_0, DRV_IO_INTENT_READWRITE );
            // SPI
            
        /*    DRV_USART0_WriteByte('I');    
            DRV_USART0_WriteByte('D');    
            DRV_USART0_WriteByte('L');    
            DRV_USART0_WriteByte('E');    */
            appData.state = APP_STATE_IDLE;
            appData.clientName = DEFAULT_NAME;
            appData.hits_to_win = 3;
            appData.isGameOver = false;
            appData.isWinner = false;
            
            break;
         }
        case APP_STATE_IDLE:{   
            //when a char is read from the USART, the data byte is pushed to the receive queue
            //iff it is within curly brackets as expected from a JSON message.
            char cmd;
            value cmdType;
            if(!DRV_USART0_ReceiverBufferIsEmpty())
            {
                // DEBUG
                //dbgOutputLoc(UART_RECEIVE_BUFFER_NOT_EMPTY);
                data = DRV_USART0_ReadByte();
             //   DRV_USART0_WriteByte(data);
                if(data == '{'){
                    charIsJunk = false;
                }
                if (!charIsJunk){
                    xQueueSendToBack(receiveQueue, &data, portMAX_DELAY);
                }
                if (data == '}'){
                    charIsJunk = true;
                }
            }
            //DEBUG
            //dbgOutputLoc(AFTER_UART_RECEIVE_BUFFER_NOT_EMPTY);
            //if the motor has a command to change, pop the char command to toMotor.
            if(!xQueueIsQueueEmptyFromISR(motorQueue)){
                //dbgOutputLoc(MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            }
            
            // DEBUG
            //dbgOutputLoc(AFTER_MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
            //if the JSON message is completed, parse it.
            if(data == '}'){ //end of a JSON command
                // DEBUG
                //dbgOutputLoc(ENTERED_DATA_EQUALS_IF);
                getCommand(&cmd, &cmdType);
                //if this is a motor command, ad a message to the motor queue
                if (cmdType == ACTIVE){
                    if (cmd == appData.clientName) {
                        sendGeneralMessage("activated",9,&appData.clientName,1,transmitQueue);
                        appData.isActiveClient = true; 
                    }
                    else {
                        sendGeneralMessage("deact",5,&appData.clientName,1,transmitQueue);
                        appData.isActiveClient = false; 
                    }
                }
                else if (!appData.isActiveClient){
                    //continue with what you were doing before.
           //         sendGeneralMessage("ghost",5,&appData.clientName,1,transmitQueue);
                }
                else if (cmdType == GAMEOVER || appData.isGameOver) {
                    appData.isGameOver = true;
                    if (cmdType == GAMEOVER && cmd != appData.clientName){
                        appData.isWinner = false;
                    }
                    if(appData.isWinner)
                        sendGeneralMessage("WinScore",8,"3",1,transmitQueue);
                    else {
                        char score[1]= {((3 - appData.hits_to_win) & 0xF) + 0x30};
                        sendGeneralMessage("LossScore",9,score,1,transmitQueue);
                    }
                }
                else if (cmdType == PING){
                    sendGeneralMessage("pong",4,&appData.clientName,1,transmitQueue);
                }
                else if (cmdType == DIRECTION) {
                    toMotorQueue = cmd;
                    xQueueSendToBack(motorQueue, &toMotorQueue, portMAX_DELAY);                
                }
                else if (cmdType == BAD){
                    sendGeneralMessage("error",5,"bad JSON",8,transmitQueue);
                }
                else if (cmdType == MODE){
                    appData.clientMode = cmd;
                    sendGeneralMessage("mode",4,&cmd,1,transmitQueue);
                }
                else if (cmdType == SETNAME){
                    appData.clientName = cmd;
                    sendGeneralMessage("setname",7,&cmd,1,transmitQueue);
                }
                else if (cmdType == DISTANCE){
                    getDistanceReading();
                }
                else if (cmdType == GOTO){
                    if (goToCoordinate(cmd)) {
                        appData.hits_to_win = appData.hits_to_win - 1;
                    }
                    if(appData.hits_to_win == 0){
                        sendGeneralMessage("WIN",3,&appData.clientName,1,transmitQueue);
                        appData.isGameOver = true;
                        appData.isWinner = true;
                    }
                }
                else {
                    sendGeneralMessage("error",5,"missing",7,transmitQueue);
                }   
            }
            // DEBUG
            //dbgOutputLoc(AFTER_DATA_EQUALS_IF);            
            OC1RS = appData.heartbeatCount;
            appData.ADCcount += 1;
            char potValue = 'x';
            potValue = PLIB_ADC_ResultGetByIndex(ADC_ID_1,appData.ADCcount);
            appData.ADCToggle = !appData.ADCToggle;
            OC1RS = (int) appData.ADCToggle;
            //change the motor direction    
            if(prevMotor != toMotor){
                // DEBUG
                //dbgOutputLoc(ENTERED_PREV_NOT_EQUALS_MOTOR);
                //DRV_USART0_WriteByte(Move);              
                changeDirection(toMotor);
                prevMotor = toMotor;
            }
        }
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Interrupt Service Routines
// *****************************************************************************
// *****************************************************************************
// This ISR goes off every 3ms
void __ISR(_TIMER_2_VECTOR, ipl6auto) _IntHandlerDrvTmrInstance0( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2) )
    {
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_2_ENTERED);
    
        count_timer_2++;
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
        
        // DEBUG
        //dbgOutputLoc(count_timer_2);
        
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_2_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// This ISR goes off every 1.5ms
void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3) )
    {
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_3_ENTERED);
        
        count_timer_3++;

        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);

        // DEBUG
        //dbgOutputLoc(count_timer_3);
        
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_3_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// This ISR goes off every 0.75ms
void __ISR(_TIMER_4_VECTOR, ipl5auto) _IntHandlerDrvTmrInstance2( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4) )
    {
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_4_ENTERED);
    
        count_timer_4++;
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
        
        // DEBUG
        //dbgOutputLoc(count_timer_4);
        
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_4_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// This ISR goes off every 0.3ms
void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_5_ENTERED);
        
        count_timer_5++;

        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);

        // DEBUG
        //dbgOutputLoc(count_timer_5);
        
        // DEBUG
        //dbgOutputLoc(ISR_TIMER_5_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}