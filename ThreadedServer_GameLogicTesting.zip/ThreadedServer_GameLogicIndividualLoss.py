import sys
import socket
import json
import threading
import collections
import time
import unittest

# from Tkinter import *

# TCP_IP = '192.168.1.100'
TCP_IP = ''
TCP_PORT = 2000
BUFFER_SIZE = 1024

allClients = set()
allClients_lock = threading.Lock()

states = {'stop': 0, 'forward': 1, 'left': 2, 'right': 3, 'back': 4}
currentState = states.get('forward')

class ThreadedServer(unittest.TestCase):

    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))

    def listen(self):
        print ("Started listening for connections...")
        clientnumber = 0
        self.sock.listen(5) # allow a maximum of 5 connections.
        while True:
            client, address = self.sock.accept()
            # client.settimeout(500)
            clientnumber+=1
            sthread = threading.Thread(target = self.listenToClient,args = (client, address, clientnumber)).start()
    def sendMessage(self, client, message):
            allClients.add(client)
            i = 0
            print ("Start Json data sent to client: " + message)
            while (i < len(message)):
                client.send(message[i]);
                i = i + 1
            print ("End Json data sent to client!")
    def sendMessageAll(self, allClients, message):
            i = 0
            print ("Start Json data sent to all clients: " + message)
            for c in allClients:
                while (i < len(message)):
                    c.send(message[i]);
                    i = i + 1
            print ("End Json data sent to all clients!")
    def handshakeMessage(self, client, message):
        self.sendMessage(client, message)
        
        data = client.recv(BUFFER_SIZE)
        print (data)
    def listenToClient(self, client, address, clientnumber):
        print ("Accepted connection from:", address)
        #remove garbage
        data = client.recv(BUFFER_SIZE)
        self.handshakeMessage(client, '{"activate":0}')
        self.handshakeMessage(client, '{"client":' + str(clientnumber) + '}')
        time.sleep(1);
        i = 0
        with allClients_lock:
            altCoordinate = False;
            while i < 10:
                #testing motor testing state
#                self.handshakeMessage(client, '{"activate":0}')
#                time.sleep(1);
                self.handshakeMessage(client, '{"mode":4}')
                time.sleep(1);
#                self.handshakeMessage(client, '{"client":3}')
#                time.sleep(1);
                self.handshakeMessage(client, '{"ping":1}')
                time.sleep(1);
                if altCoordinate:
                    self.sendMessage(client, '{"goto":A}')
                else:
                    self.sendMessage(client, '{"goto":B}')
                data = client.recv(BUFFER_SIZE)
                print (data)
                time.sleep(1);
                if "WIN" in data:
                    self.sendMessageAll(allClients, '{"gameover":1}')
                    data = client.recv(BUFFER_SIZE)
                    print (data)
                    break
                if i == 1:
                    self.handshakeMessage(client, '{"gameover":2}')
                    data = client.recv(BUFFER_SIZE)
                    print (data)
                    break;
                    
                
#                self.sendMessage(client, '{"dir":' + str(i%4 + 1) + '}')
                i = i + 1
##                self.sendMessage(client, 'hi there {"dir":1} ')
##                #time.sleep(1);
##                data = client.recv(BUFFER_SIZE)
##                print (data)
            self.handshakeMessage(client, '{"ping":1}')
            


if __name__ == "__main__":

    myServer = ThreadedServer(TCP_IP, TCP_PORT)

    while True:
        # root.mainloop()
        myServer.listen()
