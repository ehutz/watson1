#include "jsonparser.h"

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */
/** Descriptive Data Item Name

  @Summary
    Brief one-line summary of the data item.
    
  @Description
    Full description, explaining the purpose and usage of data item.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
  @Remarks
    Any additional remarks
 */
int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */

/** 
  @Function
    int ExampleLocalFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Description
    Full description, explaining the purpose and usage of the function.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

  @Precondition
    List and describe any required preconditions. If there are no preconditions,
    enter "None."

  @Parameters
    @param param1 Describe the first parameter to the function.
    
    @param param2 Describe the second parameter to the function.

  @Returns
    List (if feasible) and describe the return values of the function.
    <ul>
      <li>1   Indicates an error occurred
      <li>0   Indicates an error did not occur
    </ul>

  @Remarks
    Describe any special behavior not described above.
    <p>
    Any additional remarks.

  @Example
    @code
    if(ExampleFunctionName(1, 2) == 0)
    {
        return 3;
    }
 */
static int ExampleLocalFunction(int param1, int param2) {
    return 0;
}


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    int ExampleInterfaceFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Remarks
    Refer to the example_file.h interface header for function usage details.
 */
char parse(QueueHandle_t rQueue) 
{
    char mode[10];
    int i = 0;
    char dir;
    char jsonChar = '0';
    state = OPEN_CURLY;
    while(!xQueueIsQueueEmptyFromISR(rQueue))
    {
        xQueueReceive(rQueue, &jsonChar, portMAX_DELAY);
        switch(state)
        {
            case OPEN_CURLY:
                if(jsonChar == '{')
                {
                    state = OPEN_QUOTE;
                }
                break;
            case OPEN_QUOTE:
                if(jsonChar == '"')
                {
                    i = 0;
                    state = MODE;
                }
                break;
            case MODE:
                if(jsonChar != '"')
                {
                    mode[i] = jsonChar;
                    i++;
                }
                else{
                    state = COLON;
                }
                break; 
            /*case CLOSE_QUOTE:
                if(jsonChar == '"')
                {
                    state = COLON;
                }
                break;*/
            case COLON:
                if(jsonChar == ':')
                {
                    state = DIRECTION;
                }
                break;
            case DIRECTION:    
                if(jsonChar == '5')
                {
                    dir = 's';
                }
                else if(jsonChar == '1')
                {
                    dir = 'f';
                }
                else if(jsonChar == '2')
                {
                    dir = 'b';
                }
                else if(jsonChar == '3')
                {
                    dir = 'l';
                }
                else if(jsonChar == '4')
                {
                    dir = 'r';
                }
                else {
                    dir = 's';
                }
                state = CLOSE_CURLY;
                break;
            case CLOSE_CURLY:
                if(jsonChar == '}')
                {
                    return dir;
                }
                break;
            default:
                // TODO: DEBUG - Print out character
                break;
        }//end switch
    }//end while
    return '0';
}

void sendMessage(char out[], unsigned int length, QueueHandle_t tQueue){
    char header[] = { '\n', '\r', '{', '"', 'd', 'i', 'r' ,'"', ':' };
    char footer[] = { '}', '\n', '\r'};
    unsigned int i = 0;
    while (i < 10){
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    i = 0;
    while (i < length){
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    i = 0;
    while (i < 3){
            DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/* *****************************************************************************
 End of File
 */
