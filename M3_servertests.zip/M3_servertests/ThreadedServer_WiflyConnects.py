import sys
import socket
import json
import threading
import collections
import time
import unittest

# from Tkinter import *

# TCP_IP = '192.168.1.100'
TCP_IP = ''
TCP_PORT = 2000
BUFFER_SIZE = 1024

allClients = set()
allClients_lock = threading.Lock()

states = {'stop': 0, 'forward': 1, 'left': 2, 'right': 3, 'back': 4}
currentState = states.get('forward')

class ThreadedServer(unittest.TestCase):

    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))

    def listen(self):
        print ("Started listening for connections...")
        self.sock.listen(5) # allow a maximum of 5 connections.
        while True:
            client, address = self.sock.accept()
            # client.settimeout(500)
            sthread = threading.Thread(target = self.listenToClient,args = (client, address)).start()
                        
    def listenToClient(self, client, address):
        print ("Accepted connection from:", address)
        with allClients_lock:
            allClients.add(client)
        i = 0
        errorcount = 0
        time.sleep(1);
        data = client.recv(BUFFER_SIZE)
        print (data)
        print ("Start Json data sent to client!")
        client.send(b'{')
        client.send(b'"')
        client.send(b'a')
        client.send(b'c')
        client.send(b't')
        client.send(b'i')
        client.send(b'v')
        client.send(b'a')
        client.send(b't')
        client.send(b'e')
        client.send(b'"')
        client.send(b':')
        client.send(b'1')
        client.send(b'}')
        print ("End Json data sent to client1!")

       # time.sleep(1);
        data = client.recv(BUFFER_SIZE)
        print (data)
        while (i < 1000):
            with allClients_lock:
                    print ("Start Json data sent to client!")
                    client.send(b'{')
                    client.send(b'"')
                    client.send(b'a')
                    client.send(b'c')
                    client.send(b't')
                    client.send(b'i')
                    client.send(b'v')
                    client.send(b'a')
                    client.send(b't')
                    client.send(b'e')
                    client.send(b'"')
                    client.send(b':')
                    client.send(b'1')
                    client.send(b'}')
                    print ("End Json data sent to client1!")

#                    time.sleep(1);
                    data = client.recv(BUFFER_SIZE)
                    print (data)
                    if data != '{"activated":"0"}':
                        errorcount = errorcount + 1
                    print ("Start Json data sent to client!")
                    client.send(b'{')
                    client.send(b'"')
                    client.send(b'p')
                    client.send(b'i')
                    client.send(b'n')
                    client.send(b'g')
                    client.send(b'"')
                    client.send(b':')
                    client.send(b'1')
                    client.send(b'}')
                    print ("End Json data sent to client1!")
    
                   # time.sleep(1);
                    data = client.recv(BUFFER_SIZE)
                    print (data)
                    if data != '{"pong":"0"}':
                        errorcount = errorcount + 1                        
                    print (i)
                    i = i + 1
        print ("error count: " + str(errorcount)) 

if __name__ == "__main__":

    '''
    root = Tk()
    root.title("Server")
    root.geometry("150x80")
    app = Frame(root)
    app.grid()
    '''

    '''
    app = QApplication(sys.argv)
    widget = QWidget()
    widget.setWindowTitle("ECE 4534 Team 5 Server")

    # Create a button in the window
    btn = QPushButton("OK", widget)

    # Create the actions
    @pyqtSlot()
    def on_click():
        print('clicked')

    @pyqtSlot()
    def on_press():
        print('pressed')

    @pyqtSlot()
    def on_release():
        print('released')
     
    # connect the signals to the slots
    btn.clicked.connect(on_click)
    btn.pressed.connect(on_press)
    btn.released.connect(on_release)
    widget.show()
    app.exec_()
    '''

    myServer = ThreadedServer(TCP_IP, TCP_PORT)

    while True:
        # root.mainloop()
        myServer.listen()
