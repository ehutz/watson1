#include "jsonparser.h"

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */
/** Descriptive Data Item Name

  @Summary
    Brief one-line summary of the data item.
    
  @Description
    Full description, explaining the purpose and usage of data item.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
  @Remarks
    Any additional remarks
 */
int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */

/** 
  @Function
    int ExampleLocalFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Description
    Full description, explaining the purpose and usage of the function.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

  @Precondition
    List and describe any required preconditions. If there are no preconditions,
    enter "None."

  @Parameters
    @param param1 Describe the first parameter to the function.
    
    @param param2 Describe the second parameter to the function.

  @Returns
    List (if feasible) and describe the return values of the function.
    <ul>
      <li>1   Indicates an error occurred
      <li>0   Indicates an error did not occur
    </ul>

  @Remarks
    Describe any special behavior not described above.
    <p>
    Any additional remarks.

  @Example
    @code
    if(ExampleFunctionName(1, 2) == 0)
    {
        return 3;
    }
 */
static int ExampleLocalFunction(int param1, int param2) {
    return 0;
}


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    char parse(QueueHandle_t rQueue) 

  @Summary
 This parses the json message received by the PIC.

  @Remarks
 *
char parse(QueueHandle_t rQueue) 
{
    char jsonChar = '0';
    char key[10];
    char jsonMessage[MAX_MESSAGE_LENGTH];
    int i;
    int count = 0;
    char val = 's';
    bool isBeginning = false;
    clearKey(key);
    
    while(!xQueueIsQueueEmptyFromISR(rQueue) && jsonChar != '}' && count < MAX_MESSAGE_LENGTH)
    {
        xQueueReceive(rQueue, &jsonChar, portMAX_DELAY);
        if(jsonChar == '{') {
            if (isBeginning) { //double start brackets
                return BAD_MESSAGE;
            }
            isBeginning = true;
        }
        if (isBeginning && jsonChar != ' ') {
            jsonMessage[count] = jsonChar;
            count = count + 1;
        }
    }
    //message length was too long or it was not started with a curly bracket
    if (!isBeginning || jsonMessage[count - 1] != '}' || jsonMessage[0] != '{'){
        return BAD_MESSAGE;
    }
    int pos = 0;
    state = OPEN_CURLY;
    while (pos < count) {
        jsonChar = jsonMessage[pos];
        pos = pos + 1;
        if(pos == count - 1){ //last position
            if (jsonChar == '}')
                return val;
            else 
                return BAD_MESSAGE;
        }
        switch(state)
        {
            case OPEN_CURLY:
                if(jsonChar == '{'){
                    state = OPEN_QUOTE;
                }
                else {
                    return BAD_MESSAGE;
                }
                break;
            case OPEN_QUOTE:
                if(jsonChar == '"')
                {
                    state = KEY;
                    i=0;
                }
                else {
                    return BAD_MESSAGE;
                }
                break;
            case KEY:
                if(jsonChar != '"' && i < 10 && pos < count){
                    key[i] = jsonMessage[pos];
                    pos++;
                    i++;
                }
                if (checkKeyMatch(key, "dir", 3))
//                if(key[0] == 'd' && key[1] == 'i' && key[2] == 'r')
                {
                    value = DIRECTION;
                    state = COLON;
                }
                else if (checkKeyMatch(key, "ping", 4))
//                else if(key[0] == 'p' && key[1] == 'i' && key[2] == 'n' && key[3] == 'g')
                {
                    value = PING;
                    state = COLON;
                }
                else if (checkKeyMatch(key, "mode", 4))
//                else if(key[0] == 'm' && key[1] == 'o' && key[2] == 'd' && key[3] == 'e')
                {
                    value = MODE;
                    state = COLON;
                }
                else {
                    return BAD_MESSAGE;
                }                
                break; 
            case COLON:
                if(jsonChar == ':')
                {
                    state = VALUE;
                }
                else {
                    return BAD_MESSAGE;
                }                
                break;
            case VALUE: 
                switch(value)
                {
                    case DIRECTION:
                        if(jsonChar == STOP)
                        {
                            val = 's';
                        }
                        else if(jsonChar == FORWARD)
                        {
                            val = 'f';
                        }
                        else if(jsonChar == BACKWARD)
                        {
                            val = 'b';
                        }
                        else if(jsonChar == LEFT)
                        {
                            val = 'l';
                        }
                        else if(jsonChar == RIGHT)
                        {
                            val = 'r';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case PING:
                        if(jsonChar == PONG)
                        {
                            val = 'p';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case MODE:
                        if(jsonChar == GAME)
                        {
                            val = 'g';
                        }
                        else if(jsonChar == DEBUG)
                        {
                            val = 'd';
                        }
                        else if(jsonChar == TEST)
                        {
                            val = 't';
                        }
                        else if(jsonChar == CALIBRATE)
                        {
                            val = 'c';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    default:
                        break;
                }
                break;
            case CLOSE_CURLY:
                if(jsonChar == '}')
                {
                    return val;
                }
                else {
                    return BAD_MESSAGE;
                }                
                break;
            default:
                // TODO: DEBUG - Print out character
                
                break;
        }
    }
}*/
void parse(QueueHandle_t rQueue, char * cmd, value * cmdType) 
{
    char jsonChar = '0';
    char key[10];
    char jsonMessage[MAX_MESSAGE_LENGTH];
    value valueType = BAD;
    int i;
    int count = 0;
    char val = 's';
    bool isBeginning = false;
    clearKey(key);
    *cmdType = PING;
    //DRV_USART0_WriteByte('x');
    
    while(!xQueueIsQueueEmptyFromISR(rQueue) && jsonChar != '}' && count < MAX_MESSAGE_LENGTH)
    {
        xQueueReceive(rQueue, &jsonChar, portMAX_DELAY);
      //  DRV_USART0_WriteByte(jsonChar);

        if(jsonChar == '{') {
            if (isBeginning) { //double start brackets
                *cmd = BAD_MESSAGE;
                *cmdType = BAD;
                return;
            }
            isBeginning = true;
        }
        if (isBeginning && jsonChar != ' ') {
            jsonMessage[count] = jsonChar;
            count = count + 1;
        }
    }
   // DRV_USART0_WriteByte('z');
    //message length was too long or it was not started with a curly bracket
    if (!isBeginning || jsonMessage[count - 1] != '}' || jsonMessage[0] != '{'){
        *cmd = BAD_MESSAGE;
        *cmdType = BAD;
  //      DRV_USART0_WriteByte('0');
        return;
    }
    int pos = 0;
    state = OPEN_CURLY;
    while (pos < count) {
        jsonChar = jsonMessage[pos];
        pos = pos + 1;
        if(pos == count){ //last position
            if (jsonChar == '}') {
                *cmd = val;
                *cmdType = valueType;
            }
            else {
                *cmd = BAD_MESSAGE;
                *cmdType = BAD;
//             DRV_USART0_WriteByte(jsonChar);
            }
            return;
        }
        switch(state)
        {
            case OPEN_CURLY:
                if(jsonChar == '{'){
                    state = OPEN_QUOTE;
                }
            else {
                *cmd = BAD_MESSAGE;
                *cmdType = BAD;
    //            DRV_USART0_WriteByte('2');
                return;
            }
                break;
            case OPEN_QUOTE:
                if(jsonChar == '"')
                {
                    state = KEY;
                }
                else {
                    *cmd = BAD_MESSAGE;
                    *cmdType = BAD;
      //              DRV_USART0_WriteByte('3');
                }
                break;
            case KEY:
                i=0;
                pos--;
                while(jsonMessage[pos] != '"' && i < 10 && pos < count){
                    key[i] = jsonMessage[pos];
                    pos++;
                    i++;
                }
                pos++;
        //        DRV_USART0_WriteByte('a');

                if (checkKeyMatch(key, "dir", 3))
//                if(key[0] == 'd' && key[1] == 'i' && key[2] == 'r')
                {
  //                  DRV_USART0_WriteByte('d');
                    valueType = DIRECTION;
                    state = COLON;
                }
                else if (checkKeyMatch(key, "ping", 4))
//                else if(key[0] == 'p' && key[1] == 'i' && key[2] == 'n' && key[3] == 'g')
                {
                    valueType = PING;
                    state = COLON;
                }
                else if (checkKeyMatch(key, "mode", 4))
//                else if(key[0] == 'm' && key[1] == 'o' && key[2] == 'd' && key[3] == 'e')
                {
                    valueType = MODE;
                    state = COLON;
                }
                else {
                    *cmd = BAD_MESSAGE;
                    *cmdType = BAD;
        //            DRV_USART0_WriteByte('4');
                    return;
                }                
                break; 
            case COLON:
                if(jsonChar == ':')
                {
                    state = VALUE;
                }
                else {
                    *cmd = BAD_MESSAGE;
                    *cmdType = BAD;
     //               DRV_USART0_WriteByte(jsonChar);
                    return;
                }                
                break;
            *cmdType = valueType;
            case VALUE: 
                switch(valueType)
                {
                    case DIRECTION:
                        if(jsonChar == STOP)
                        {
                            val = 's';
                        }
                        else if(jsonChar == FORWARD)
                        {
                            val = 'f';
                        }
                        else if(jsonChar == BACKWARD)
                        {
                            val = 'b';
                        }
                        else if(jsonChar == LEFT)
                        {
                            val = 'l';
                        }
                        else if(jsonChar == RIGHT)
                        {
                            val = 'r';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case PING:
                        if(jsonChar == PONG)
                        {
                            val = 'p';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case MODE:
                        if(jsonChar == GAME)
                        {
                            val = 'g';
                        }
                        else if(jsonChar == DEBUG)
                        {
                            val = 'd';
                        }
                        else if(jsonChar == TEST)
                        {
                            val = 't';
                        }
                        else if(jsonChar == CALIBRATE)
                        {
                            val = 'c';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    default:
                        break;
                }
                break;
            case CLOSE_CURLY:
                if(jsonChar == '}')
                {
                     *cmd = val;
                }
                else {
                    *cmd = BAD_MESSAGE;
                    *cmdType = BAD;
       //             DRV_USART0_WriteByte('6');
                    return;
                }                
                break;
            default:
                // TODO: DEBUG - Print out character
                
                break;
        }
    }
}

void clearKey(char keyArray[])
{
    int i;
    for(i = 0; i < 10; i++)
    {
        keyArray[i] = NULL;
    }
}

bool checkKeyMatch (char keyArray[], char matchArray[], int length){
    int pos = 0;
    while (pos < length){
        if (keyArray[pos] != matchArray[pos]){
            /*DRV_USART0_WriteByte(matchArray[0]);
            DRV_USART0_WriteByte(matchArray[1]);
            DRV_USART0_WriteByte(matchArray[2]);
            DRV_USART0_WriteByte(keyArray[0]);
            DRV_USART0_WriteByte(keyArray[1]);
            DRV_USART0_WriteByte(keyArray[2]);*/
            return false;
        }
        pos++;
    }
//    DRV_USART0_WriteByte('c');
    return true;
}
/* *****************************************************************************
 End of File
 */
