/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************
#include "FreeRTOS.h"
#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )
 */

void APP_Initialize ( void )
{
    Motor_Init();
    Motor_Stop();
    
    DRV_USART0_WriteByte('X');
    
    appData.state = APP_STATE_INIT;
    
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    ultrasonicQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    
    // START: Initializations for reflectance sensor in timer 5 ISR
    count_timer_5 = 0;
    blackCount = 0;
    count2 = 0;
    count3 = 0;
    c = 0;
    sense = 1;
    count = 0;
    SENSE = out;
    // END: Initializations for reflectance sensor in timer 5 ISR
            
    // START: Initializations for ultrasonic sensor in timer 5 ISR
    count_ultrasonic = 0;
    US_distance = 0;
    pulse_start = 0;
    pulse_end = 0;
    flag = false;
    echo_done = false;
    // END: Initializations for ultrasonic sensor in timer 5 ISR
}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
void APP_Tasks ( void )
{
    switch ( appData.state )
    {
        case APP_STATE_INIT:
        {
            DRV_USART0_WriteByte('Y');
            // START TIMERS 2,3,4,5
            //DRV_TMR0_Start();
            //DRV_TMR1_Start();
            //DRV_TMR2_Start();
            DRV_TMR3_Start();
            // TIMER 2,3,4,5
            
            appData.state = APP_STATE_IDLE;
           
            //appData.state = APP_STATE_SERVICE_TASKS;
            
            break;
         }
        case APP_STATE_IDLE:
        {
            DRV_USART0_WriteByte('Z');
            if(US_distance <= 15*10 && US_distance != 0)
            {
                DRV_USART0_WriteByte('H');
                Motor_Stop();
            }
            else if(US_distance > 15*10)
            {
                DRV_USART0_WriteByte('L');
                Motor_Backward();
            }
            if(count_ultrasonic > 10)
                DRV_USART0_WriteByte('C');
            break;
        }
        case APP_STATE_SERVICE_TASKS:
        {
            /*char test_ultrasonic;
            uint32_t test_ultrasonic_2;
            
            if(!xQueueIsQueueEmptyFromISR(receiveQueue))
            {
                DRV_USART0_WriteByte('X'); // testing that code reaches this point
                xQueueReceive(receiveQueue, &test_ultrasonic, portMAX_DELAY);
                DRV_USART0_WriteByte(test_ultrasonic);
            }
            
            if(!xQueueIsQueueEmptyFromISR(ultrasonicQueue))
            {
                DRV_USART0_WriteByte('U'); // testing that code reaches this point
                xQueueReceive(ultrasonicQueue, &test_ultrasonic_2, portMAX_DELAY);
                DRV_USART0_WriteByte(test_ultrasonic_2);
            }*/
            break;
        }
        default:
        {
            break;
        }
    }  
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Interrupt Service Routines
// *****************************************************************************
// *****************************************************************************

//Timer2 is internal, period of 20us
/*void __ISR(_TIMER_2_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance0(void)
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2))
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_ENTERED);

        count_timer_2++;

        if (needToStop == 1)
        {
            DRV_OC0_PulseWidthSet(0);
            DRV_OC1_PulseWidthSet(0);
        }
        else
        {
            if (needToTurn == 0)
            {

                DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);

                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT

                if (timerThreeVal < timerFourVal)
                {
                    // the RIGHT motor is going faster. Speed up left motor.

                    float offset = timerFourVal - timerThreeVal;
                    LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH + (offset / timerThreeVal) * 100;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH - (offset / timerFourVal) * 100;

                    //DRV_TMR1_CounterClear();
                    //DRV_TMR2_CounterClear();
                }
                else if (timerThreeVal > timerFourVal)
                {
                    // the LEFT motor is going faster. Speed up right motor.

                    float offset = timerThreeVal - timerFourVal;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH + (offset / timerFourVal) * 200;
                    //LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH - (offset / timerThreeVal);

                }
            }
            else
            {
                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT
                int leftStopped = 0;
                int rightStopped = 0;

                // 90 DEGREE TURN (RIGHT / LEFT)
                // 3
                // 4

                // 180 DEGREE TURN (LEFT)
                // 6
                // 6

                /*
                 TODO: INCLUDE THIS IN THE NAVIGATION CODE.
                 */

                /*if (timerThreeVal >= 6)
                {
                    DRV_OC0_PulseWidthSet(0);
                    leftStopped = 1;
                }
                if (timerFourVal >= 6)
                {
                    DRV_OC1_PulseWidthSet(0);
                    rightStopped = 1;
                }
            }
        }

        if (RIGHT_PULSE_WIDTH >= 1600 || LEFT_PULSE_WIDTH >= 1600)
        {
            RIGHT_PULSE_WIDTH = 1100;
            LEFT_PULSE_WIDTH = 1200;
        }

        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);

        // DEBUG
        dbgOutputLoc(count_timer_2);

        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}*/

// Timer 3 is externally sourced, period of 1.6ms
/*void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3) )
    {
        count_timer_3++;
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

//Timer 4 is externally sourced, period of 1.6ms
void __ISR(_TIMER_4_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance2( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4) )
    {
        count_timer_4++;
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}*/
// THIS COMMENTED OUT ISR WORKS FOR ULTRASONIC SENSOR WITH PERIOD 10 (1 uS))
/*void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        if(count_ultrasonic == 0)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 ); // Clear trigger
        }
        else if(count_ultrasonic == 1000000) // Wait 1 sec for trigger input to settle **MESS WITH THIS**
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_F, 0 );
        }
        else if(count_ultrasonic == 1000010) // wait 10us until set trig low **MESS WITH THIS**
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 );
        }
        
        if(count_ultrasonic >= 1000010 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            pulse_start = count_ultrasonic-1000009;
        }
        if(count_ultrasonic >= 1000010 && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            flag = true;
            pulse_end = count_ultrasonic-1000009;
        }
        if(flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            echo_done = true;
        }
        
        count_ultrasonic++;
        
        if(echo_done)
        {
            US_distance = ((pulse_end - pulse_start) * 0.01715)*10*3; //3 is a magic number, *10 gives a decimal place
            echo_done = false; //reset
            count_ultrasonic = 0; //reset
            flag = false; //reset
        }
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}*/
// THIS COMMENTED OUT ISR WORKS FOR ULTRASONIC SENSOR WITH PERIOD 10 (1 uS))
/*void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        if(count_ultrasonic == 0)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_E, 1 ); // Clear trigger
        }
        else if(count_ultrasonic == 1000000) // Wait 1 sec for trigger input to settle **MESS WITH THIS**
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_E, 1 );
        }
        else if(count_ultrasonic == 1000010) // wait 10us until set trig low **MESS WITH THIS**
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_E, 1 );
        }
        
        if(count_ultrasonic >= 1000010 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_E, 0))
        {
            pulse_start = count_ultrasonic-1000009;
        }
        if(count_ultrasonic >= 1000010 && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_E, 0))
        {
            flag = true;
            pulse_end = count_ultrasonic-1000009;
        }
        if(flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_E, 0))
        {
            echo_done = true;
        }
        
        count_ultrasonic++;
        
        if(echo_done)
        {
            US_distance = ((pulse_end - pulse_start) * 0.01715)*10*3; //3 is a magic number, *10 gives a decimal place
            echo_done = false; //reset
            count_ultrasonic = 0; //reset
            flag = false; //reset
        }
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}*/

// THIS ISR WORKS FOR ULTRASONIC SENSOR WITH PERIOD 100 (10 uS))
void __ISR(_TIMER_5_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    //count_timer_5++;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        // START: Ultrasonic sensor logic
        if(count_ultrasonic == 0)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_B, 13 ); // Clear trigger
        }
        else if(count_ultrasonic == 100000) // Wait 1 sec for trigger input to settle **MESS WITH THIS**
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_B, 13 );
        }
        else if(count_ultrasonic == 100001) // wait 10us until set trig low **MESS WITH THIS**
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_B, 13 );
        }
        
        if(count_ultrasonic >= 100001 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_B, 12))
        {
            pulse_start = (count_ultrasonic*10)-100000;
        }
        if(count_ultrasonic >= 100001 && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_B, 12))
        {
            flag = true;
            pulse_end = (count_ultrasonic*10)-100000;
        }
        if(flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_B, 12))
        {
            echo_done = true;
        }
        
        count_ultrasonic++;
        
        if(echo_done)
        {
            US_distance = ((pulse_end - pulse_start) * 0.01715)*10; //*10 gives a decimal place
            echo_done = false; //reset
            count_ultrasonic = 0; //reset
            flag = false; //reset
        }
        
        
        // END: Ultrasonic sensor logic
        
        // START: Reflectance sensor logic
        /*if(sense == 1)
        {
            c = 0; // c is there to limit the number of times the sensor spits out 'B'
        }*/
        
        /*if(count2 > 10000)
        {
            // count 2 and count 3 will generate sense = 1 ~ 10 times a second.
           count3++;
           count2 = 0;
           if(count3 > 10)
           {
                count3 = 0;
                sense = 1;
           }
        }
        else
        {
            count2++;
        }*/

            //*************//
            /*switch(SENSE)
            {
                case out:
                {
                    if(sense == 1)
                    {
                        // Set the sensor to output mode.
                        TRISE = 0x0300; //set pins RE0 to RE7 to 0: output
                        LATE = 0x00FF;
                        SENSE = in;
                        count = 0; // reset counts to have accurate decay.
                        count_timer_5 = 0;
                    }
                    break;
                }
                case in:
                {
                    if(count_timer_5 > 1)
                    {
                        // Set sensor to input mode and let it decay.
                        TRISE = 0x3FF; //set pins RE0 to RE7 to 1: input
                        LATE = 0x0000; //value sent to pins is zero, let them decay
                        if (PORTE & 0xFF)
                        {
                            // When sensor decays, track how much time it took.
                            count = count_timer_5-2; // Subtract 2 because count_timer_5 starts at 2 not 0 in this switch case
                        }
                        else
                            SENSE = stopped;
                        //DRV_USART0_WriteByte(count);
                    }
                    break;
                }
                case stopped:
                {
                    // Based on how much time it took to decay, the sensor reading will either be black or white.
                    if(count < 90)
                    { //white
                        //toMotor = MOTOR_BACKWARD;
                        if(c < 1)
                        {
                            //blackCount = 0;
                        }
                        else
                            c++;
                        //DRV_USART0_WriteByte(0x30);
                    }
                    else 
                    {//black
                        //toMotor = MOTOR_LEFT;
                        if(c < 1)
                        {
                            blackCount++;
                        }
                        else
                            c++;
                        //DRV_USART0_WriteByte(0x31);
                    }
                    sense = 0;
                    SENSE = out;  
                    break;
                }
            }*/
            // END: Reflectance sensor logic
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}