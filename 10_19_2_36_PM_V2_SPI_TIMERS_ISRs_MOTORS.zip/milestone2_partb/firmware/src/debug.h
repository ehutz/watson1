/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _DEBUG_H    /* Guard against multiple inclusion */
#define _DEBUG_H


#include "system_config/default/framework/driver/usart/drv_usart_static.h"
#include "../framework/system/ports/sys_ports.h"

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


    /* ************************************************************************** */
    /* ************************************************************************** */
    /* Section: Constants                                                         */
    /* ************************************************************************** */
    /* ************************************************************************** */

    /*  A brief description of a section can be given directly below the section
        banner.
     */


    /* ************************************************************************** */
    /** Descriptive Constant Name

      @Summary
        Brief one-line summary of the constant.
    
      @Description
        Full description, explaining the purpose and usage of the constant.
        <p>
        Additional description in consecutive paragraphs separated by HTML 
        paragraph breaks, as necessary.
        <p>
        Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
      @Remarks
        Any additional remarks
     */
    
// Task constants
#define TASK_ENTERED                                0x01
#define TASK_BEFORE_SEND_RECEIVE_QUEUE              0x02
#define TASK_AFTER_SEND_RECEIVE_QUEUE               0x03
#define TASK_ENTER_WHILE_LOOP                       0x04
#define TASK_EXIT_WHILE_LOOP                        0x05

// ISR constants
#define ISR_TIMER_3_ENTERED                         0x10
#define ISR_TIMER_3_EXIT                            0x11
#define ISR_BEFORE_SEND_RECEIVE_QUEUE               0x12
#define ISR_AFTER_SEND_RECEIVE_QUEUE                0x13
#define ISR_TIMER_2_ENTERED                         0x14
#define ISR_TIMER_2_EXIT                            0x15
#define ISR_TIMER_4_ENTERED                         0x16
#define ISR_TIMER_4_EXIT                            0x17
#define ISR_TIMER_5_ENTERED                         0x18
#define ISR_TIMER_5_EXIT                            0x19
    
// UART constants
#define UART_RECEIVE_BUFFER_NOT_EMPTY               0x20
#define AFTER_UART_RECEIVE_BUFFER_NOT_EMPTY         0x21

// Queue constants
#define MOTOR_QUEUE_FROM_ISR_NOT_EMPTY              0x30
#define AFTER_MOTOR_QUEUE_FROM_ISR_NOT_EMPTY        0x31
    
// If statement constants
#define ENTERED_DATA_EQUALS_IF                      0x40
#define AFTER_DATA_EQUALS_IF                        0x41 
#define ENTERED_PREV_NOT_EQUALS_MOTOR               0x42

// Switch statement constants
#define ENTERED_MOTOR_SWITCH                        0x50
    
// Motor command function constants
#define RECEIVE_QUEUE_FROM_ISR_NOT_EMPTY            0x60
#define AFTER_RECEIVE_QUEUE_FROM_ISR_NOT_EMPTY      0x61
#define BEFORE_PARSE_RECEIVE_QUEUE                  0x62
#define AFTER_PARSE_RECEIVE_QUEUE                   0x63
    
// Timer debug constants
#define BEFORE_START_TIMER_2                        0x70
#define AFTER_START_TIMER_2                         0x71
#define BEFORE_START_TIMER_3                        0x72
#define AFTER_START_TIMER_3                         0x73

// SPI debug constants
#define ERROR_OPENING_SPI       0x80
#define CASE_SEND_READ_CMD      0x81
#define CASE_WAIT_FOR_REPLY     0x82
#define CASE_GET_DATA           0x83
#define CASE_WAIT_FOR_DATA      0x84
#define CASE_READ_COMPLETE      0x85
#define ENTER_SPI_INTERRUPT     0x86
#define EXIT_SPI_INTERRUPT      0x87
    
    
    // *****************************************************************************
    // *****************************************************************************
    // Section: Data Types
    // *****************************************************************************
    // *****************************************************************************

    /*  A brief description of a section can be given directly below the section
        banner.
     */


    // *****************************************************************************

    /** Descriptive Data Type Name

      @Summary
        Brief one-line summary of the data type.
    
      @Description
        Full description, explaining the purpose and usage of the data type.
        <p>
        Additional description in consecutive paragraphs separated by HTML 
        paragraph breaks, as necessary.
        <p>
        Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

      @Remarks
        Any additional remarks
        <p>
        Describe enumeration elements and structure and union members above each 
        element or member.
     */


    // *****************************************************************************
    // *****************************************************************************
    // Section: Interface Functions
    // *****************************************************************************
    // *****************************************************************************

    /*  A brief description of a section can be given directly below the section
        banner.
     */

    // *****************************************************************************
    /**
      @Function
        int ExampleFunctionName ( int param1, int param2 ) 

      @Summary
        Brief one-line description of the function.

      @Description
        Full description, explaining the purpose and usage of the function.
        <p>
        Additional description in consecutive paragraphs separated by HTML 
        paragraph breaks, as necessary.
        <p>
        Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

      @Precondition
        List and describe any required preconditions. If there are no preconditions,
        enter "None."

      @Parameters
        @param param1 Describe the first parameter to the function.
    
        @param param2 Describe the second parameter to the function.

      @Returns
        List (if feasible) and describe the return values of the function.
        <ul>
          <li>1   Indicates an error occurred
          <li>0   Indicates an error did not occur
        </ul>

      @Remarks
        Describe any special behavior not described above.
        <p>
        Any additional remarks.

      @Example
        @code
        if(ExampleFunctionName(1, 2) == 0)
        {
            return 3;
        }
     */
    void dbgUARTVal(unsigned char outVal);

    void dbgOutputVal(unsigned char outVal);
    
    void dbgOutputLoc(unsigned char outVal);

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _DEBUG_H */

/* *****************************************************************************
 End of File
 */
