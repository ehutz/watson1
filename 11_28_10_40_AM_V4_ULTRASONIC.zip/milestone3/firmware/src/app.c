/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************
#include "FreeRTOS.h"
#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )
 */

void APP_Initialize ( void )
{
    appData.state = APP_STATE_INIT;
    
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    if(receiveQueue == 0)
        DRV_USART0_WriteByte('F'); // Failed to create queue
    ultrasonicQueue = xQueueCreate(30, sizeof(unsigned int));
    if(ultrasonicQueue == 0)
        DRV_USART0_WriteByte('F'); // Failed to create queue
    
    charIsJunk = true;
    count_timer_5 = 0;
    US_distance = 0;
    pulse_start = 0;
    pulse_end = 0;
    flag = false;
    echo_done = false;
    
    US_STATE = COUNT_0;
    
    // Turn LED4 on
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_A, 3 );
}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
void APP_Tasks ( void )
{
    switch ( appData.state )
    {
        case APP_STATE_INIT:
        {
            // START TIMER 5
            DRV_TMR3_Start();
            // TIMER 5
            
            appData.state = APP_STATE_IDLE;
           
            //appData.state = APP_STATE_SERVICE_TASKS;
            
            break;
         }
        case APP_STATE_IDLE:
        {
            if(count_timer_5 % 100000 == 0)
                sendNumber(US_distance);
            
            /*uint32_t distance;
            xQueueReceive(ultrasonicQueue, &distance, portMAX_DELAY);
            sendNumber(distance);*/
            
            // START: ULTRASONIC SENSOR
            /*if(count_timer_5 == 0)
            {
                SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 ); // Clear trigger
            }
            else if(count_timer_5 == 100000) // Wait 1 sec for trigger input to settle
            {
                DRV_USART0_WriteByte('S'); // SET
                SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_F, 0 );
            }
            else if(count_timer_5 == 100002) //
            {
                DRV_USART0_WriteByte('C'); // CLEAR
                SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 );
            }*/
            /*if(count_timer_5 >= 100001 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
            {
                flag = true;
             
                pulse_start = (count_timer_5-100000)*10;
                //sendNumber(pulse_start);
                DRV_USART0_WriteByte('H');  // HIGH
                
                //sendNumber(count_timer_5-2);
            }*/
            /*if(flag && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
            {
                pulse_end = (count_timer_5-100000)*10;
                //sendNumber(pulse_end);
                //DRV_USART0_WriteByte('L'); // LOW
                
                //sendNumber(US_distance_low - US_distance_high); // Subtract gives high time of echo signal
                
                sendNumber((pulse_end - pulse_start) * 0.01715); // distance in cm, speed of sound = 340m/s
                
                count_timer_5 = 0; //reset
                flag = false; //reset
            }*/
            // END: ULTRASONIC SENSOR
            
            /*uint32_t test_ultrasonic_2;
            
            if(!xQueueIsQueueEmptyFromISR(ultrasonicQueue))
            {
                DRV_USART0_WriteByte('U'); // testing that code reaches this point
                xQueueReceive(ultrasonicQueue, &test_ultrasonic_2, portMAX_DELAY);
                sendNumber(test_ultrasonic_2);
            }*/
            break;
        }
        case APP_STATE_SERVICE_TASKS:
        {
            char test_ultrasonic;
            uint32_t test_ultrasonic_2;
            
            if(!xQueueIsQueueEmptyFromISR(receiveQueue))
            {
                DRV_USART0_WriteByte('X'); // testing that code reaches this point
                xQueueReceive(receiveQueue, &test_ultrasonic, portMAX_DELAY);
                DRV_USART0_WriteByte(test_ultrasonic);
            }
            
            if(!xQueueIsQueueEmptyFromISR(ultrasonicQueue))
            {
                DRV_USART0_WriteByte('U'); // testing that code reaches this point
                xQueueReceive(ultrasonicQueue, &test_ultrasonic_2, portMAX_DELAY);
                DRV_USART0_WriteByte(test_ultrasonic_2);
            }
            break;
        }
        default:
        {
            break;
        }
    }  
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Interrupt Service Routines
// *****************************************************************************
// *****************************************************************************

// This ISR goes off every 10us
/*void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_5_ENTERED);
        
        // DEBUG
        dbgOutputLoc(count_timer_5);
        
        if(count_timer_5 == 0)
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_F, 0 );
            count_timer_5++;
        }
        else if(count_timer_5 == 1)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 );
            count_timer_5++;
            countUS = 0;
        }
        else
            countUS++;
     
        if( !flag && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1) )
        {
            flag = true;
            //US_distance = (countUS*10)/58; //distance in centimeters
        }
        if( flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1) )
        {
            
            US_distance = (countUS*10)/58; //distance in centimeters
            //US_distance = ((countUS*10) * .034 / 2)*10;
            
            count_timer_5 = 0; //reset
            flag = false;
        }
        
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
       
        // DEBUG
        dbgOutputLoc(ISR_TIMER_5_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}*/
void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        if(count_timer_5 == 0)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 ); // Clear trigger
        }
        else if(count_timer_5 == 1000000) // Wait 1 sec for trigger input to settle
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_F, 0 );
        }
        else if(count_timer_5 == 1000010) // wait 10us until set trig low
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 );
        }
        
        if(count_timer_5 >= 1000010 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            pulse_start = count_timer_5-1000009;
        }
        if(count_timer_5 >= 1000010 &&/*flag &&*/ SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            flag = true;
            pulse_end = count_timer_5-1000009;
            //US_distance = (pulse_end - pulse_start) * 0.01715;
            //xQueueSendFromISR(ultrasonicQueue, &US_distance, &pxHigherPriorityTaskWoken);
            //sendNumber((pulse_end - pulse_start) * 0.01715); // distance in cm, speed of sound = 340m/s
        }
        if(flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            echo_done = true;
        }
        
        count_timer_5++;
        
        if(echo_done)
        {
            US_distance = ((pulse_end - pulse_start) * 0.01715)*10*2.6; //2.6 is a magic number
            echo_done = false; //reset
            count_timer_5 = 0; //reset
            flag = false; //reset
        }
        
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}


// Old interrupt code

//char toQueue;
/*switch(US_STATE)
{
  case COUNT_0:
  {
      SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 ); // Clear trigger

      if(count_timer_5 == 100000) // Wait 1 sec
          US_STATE = TRIG_SET_HIGH;

      break;
  }
  case TRIG_SET_HIGH:
  {
      //DRV_USART0_WriteByte('S'); // SET
      toQueue = US_SET_TRIG;
      xQueueSendToBack(receiveQueue, &toQueue, portMAX_DELAY);

      SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_F, 0 );

      if(count_timer_5 == 100001)
          US_STATE = TRIG_SET_LOW;

      break;
  }
  case TRIG_SET_LOW:
  {
      //DRV_USART0_WriteByte('C'); // CLEAR
      toQueue = US_CLEAR_TRIG;
      xQueueSendToBack(receiveQueue, &toQueue, portMAX_DELAY);

      SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 );

      if(count_timer_5 >= 100001 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
          US_STATE = ECHO_READ_LOW;

      break;
  }
  case ECHO_READ_LOW:
  {
      flag = true;
      //US_distance_high = ((count_timer_5-200001)*10)/58; //distance in centimeters
      US_distance_high = (count_timer_5-100000)*10;
      //sendNumber(US_distance_high);

      //DRV_USART0_WriteByte('H');  // HIGH
      toQueue = US_ECHO_LOW;
      xQueueSendToBack(receiveQueue, &toQueue, portMAX_DELAY);

      if(flag && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
          US_STATE = ECHO_READ_HIGH;

      break;
  }
  case ECHO_READ_HIGH:
  {
      //US_distance_low = ((count_timer_5-200001)*10)/58; //distance in centimeters
      US_distance_low = (count_timer_5-100000)*10;
      //sendNumber(US_distance_low);

      //DRV_USART0_WriteByte('L'); // LOW
      toQueue = US_ECHO_HIGH;
      xQueueSendToBack(receiveQueue, &toQueue, portMAX_DELAY);

      //sendNumber(US_distance_low - US_distance_high); // Subtract gives high time of echo signal
      uint32_t distance = US_distance_low - US_distance_high;
      xQueueSendToBack(ultrasonicQueue, &distance, portMAX_DELAY);

      //sendNumber((US_distance_low - US_distance_high) * 0.01715);

      count_timer_5 = 0; //reset
      flag = false; //reset

      US_STATE = COUNT_0;

      break;
  }
  default:
      break;

  count_timer_5++;
  PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
}*/