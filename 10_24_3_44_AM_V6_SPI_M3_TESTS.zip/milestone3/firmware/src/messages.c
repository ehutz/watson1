/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */
#include "messages.h"


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */



/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*******************************************************************************
  Function:
    void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'd', 'i', 'r' ,'"', ':','"' };
    unsigned int header_length = 8;
    
    char footer[] = {'"', '}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'p', 'i', 'n' ,'g','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'm', 'o', 'd' ,'e','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendTestMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendTestMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 't', 'e', 's' ,'t','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendTestMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendTestValMessage(uint8_t val, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 't', 'e', 's' ,'t','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    unsigned halfword = (val & 0xF);
    
    DRV_USART0_WriteByte('0');            
    DRV_USART0_WriteByte('x');            
    DRV_USART0_WriteByte((val >> 4) + '0');            
    DRV_USART0_WriteByte(halfword + '0');     
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendErrorMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendErrorMessage(char out[], unsigned int length)
{
    char header[] = { '{', '"', 'E', 'R', 'R' ,'O','R','"', ':','"' };
    unsigned int header_length = 10;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
    DRV_USART0_WriteByte('\n');
    DRV_USART0_WriteByte('\r');
}

void sendMessage(char out[], unsigned int length)
{
    char header[] = { '{', '"', 'P', 'A', 'S' ,'S','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        DRV_USART0_WriteByte(header[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        DRV_USART0_WriteByte(out[i]);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        DRV_USART0_WriteByte(footer[i]);            
        i=i+1;
    }
    DRV_USART0_WriteByte('\n');
    DRV_USART0_WriteByte('\r');
}
/* *****************************************************************************
 End of File
 */
