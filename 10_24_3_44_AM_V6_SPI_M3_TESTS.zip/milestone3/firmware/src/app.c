/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************
#include "FreeRTOS.h"
#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    char getCommand ( void )
 */
char getCommand()
{
    char temp = '0';
    
    temp = parse(receiveQueue);
    
    return temp;
}

/*******************************************************************************
  Function:
    void testCaseOneSpi ( void )
 */
uint8_t testCaseOneSpi()
{
    uint8_t countSpiStates = 0;
    SPI_State = SEND_READ_CMD;
    
    switch(SPI_State)
    {
        case SEND_READ_CMD:
            countSpiStates++;
            TXbuffer[0] = 0xA4;

            Write_Buffer_Handle = DRV_SPI_BufferAddWrite(SPIHandle, TXbuffer, 1, 0, 0);

            // DEBUG
            dbgOutputLoc(CASE_SEND_READ_CMD);

            if(Write_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
            {
                SPI_State = WAIT_FOR_REPLY_2;
            }

            break;
        case WAIT_FOR_REPLY_2:
            countSpiStates++;
            
            // DEBUG
            dbgOutputLoc(CASE_WAIT_FOR_REPLY);

            if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus( Write_Buffer_Handle ) )
            {
                SPI_State = GET_DATA;
            }

            break;
        case GET_DATA:
            countSpiStates++;
            
            // DEBUG
            dbgOutputLoc(CASE_GET_DATA);

            Read_Buffer_Handle = DRV_SPI_BufferAddRead( SPIHandle, RXbuffer, 1, 0, 0);
            if(Read_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
            {
                SPI_State = WAIT_FOR_DATA;
            }
            break;
        case WAIT_FOR_DATA:
            countSpiStates++;
            
            // DEBUG
            dbgOutputLoc(CASE_WAIT_FOR_DATA);

            if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus(Read_Buffer_Handle))
            {
                SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_G, 9 ); //(active low)
            }
            
            return countSpiStates;
            break;
        default:
            break;
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )
 */

void APP_Initialize ( void )
{
    // Initialize ports for the motor control
    Motor_Init();
    
    // Start the ADC
    DRV_ADC_Open();
    DRV_ADC_Start();
  
    appData.state = APP_STATE_INIT;
    /* Place the App state machine in its initial state. */
    // Used to blink LED 4
    appData.heartbeatTimer = DRV_HANDLE_INVALID;
    appData.heartbeatCount = 0;
    appData.heartbeatToggle = false;
    
    appData.ADCToggle = false;
    appData.ADCcount = 0;
    
    // Initial state for motor state machine 
    Move = stop;
    
    // Initialize queues
    motorQueue = xQueueCreate(30, sizeof(unsigned int));
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    transmitQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    count_timer_5 = 0;
    
    // Gives a starting point in DigiView
    dbgOutputLoc(0xFF);
    
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_A, 3 );
    
    // Set SPI Slave Select (active low))
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_G, 9 );
    //SPI_State = SEND_WRITE_CMD;
    //SPI_State = SEND_READ_CMD;
    
    //Initializing Liz's milestone 3 test case variables
    SPI_States_Hit = 0;
}

// This ISR should go off every 200ms
/*static void APP_TimerCallback ( uintptr_t context, uint32_t alarmCount )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
   
    // DEBUG
    dbgOutputLoc(ISR_ENTERED);
    
    int to_send;

    // START: LED BLINK
    appData.heartbeatCount++;
    if (appData.heartbeatCount >= APP_HEARTBEAT_COUNT_MAX)
    {
        appData.heartbeatCount = 0;
        appData.heartbeatToggle = true;
    }
    to_send = appData.heartbeatCount;
    // END: LED BLINK
    
    // DEBUG
    dbgOutputLoc(ISR_EXIT);
    
    //xQueueSendToBackFromISR(motorQueue, &to_send, &pxHigherPriorityTaskWoken);
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}*/

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
void APP_Tasks ( void )
{
    char prevMotor = '0';
    toMotor = '0';
    char toMotorQueue = '0';
    char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;
    
    // LED controls
    if (appData.heartbeatToggle == true)
    {
        SYS_PORTS_PinToggle(PORTS_ID_0, APP_HEARTBEAT_PORT, APP_HEARTBEAT_PIN);
        appData.heartbeatToggle = false;
    }

    switch ( appData.state )
    {
        case APP_STATE_INIT:
        {
            // START TIMER 2
            /*dbgOutputLoc(BEFORE_START_TIMER_2);
            appData.heartbeatTimer = DRV_TMR_Open( APP_HEARTBEAT_TMR, DRV_IO_INTENT_EXCLUSIVE);
            if ( DRV_HANDLE_INVALID != appData.heartbeatTimer )
            {
                DRV_TMR_AlarmRegister(appData.heartbeatTimer,
                APP_HEARTBEAT_TMR_PERIOD,
                APP_HEARTBEAT_TMR_IS_PERIODIC,
                (uintptr_t)&appData,
                APP_TimerCallback);
                DRV_TMR_Start(appData.heartbeatTimer);
                appData.state = APP_STATE_IDLE;
            }
            dbgOutputLoc(AFTER_START_TIMER_2);*/
            // END TIMER 2
            
            // START TIMER 2
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
            DRV_TMR0_Start();
            // TIMER 2
            
            // START TIMER 3
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
            DRV_TMR1_Start();
            // TIMER 3
            
            // START TIMER 4
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
            DRV_TMR2_Start();
            // TIMER 4
            
            // START TIMER 5
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_5);
            DRV_TMR3_Start();
            // TIMER 5
            
            // SPI
            SPIHandle = DRV_SPI_Open(DRV_SPI_INDEX_0, DRV_IO_INTENT_READWRITE );
            if( DRV_HANDLE_INVALID == SPIHandle )
            {
                // Unable to open the driver
                dbgOutputLoc(ERROR_OPENING_SPI);
            }
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_G, 9 ); //(active low)
            // SPI
            
            appData.state = APP_STATE_IDLE;
           
            //appData.state = APP_STATE_SERVICE_TASKS;
            
            //appData.state = TEST_SPI_BUS;
            
            break;
         }
        case APP_STATE_IDLE:
        {
            if(!DRV_USART0_ReceiverBufferIsEmpty())
            {
                // DEBUG
                dbgOutputLoc(UART_RECEIVE_BUFFER_NOT_EMPTY);
                
                data = DRV_USART0_ReadByte();
                //DRV_USART0_WriteByte(data);
                if(data == '{')
                {
                    charIsJunk = false;
                }
                if (!charIsJunk){
                    xQueueSendToBack(receiveQueue, &data, portMAX_DELAY);
                }
                if (data == '}')
                {
                    charIsJunk = true;
                }
            }
            
            //DEBUG
            dbgOutputLoc(AFTER_UART_RECEIVE_BUFFER_NOT_EMPTY);
            
            if(!xQueueIsQueueEmptyFromISR(motorQueue))
            {
                dbgOutputLoc(MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
                
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            }
            
            // DEBUG
            dbgOutputLoc(AFTER_MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
            
            if(data == '}') //end of a JSON command
            {
                // DEBUG
                dbgOutputLoc(ENTERED_DATA_EQUALS_IF);
                
                toMotorQueue = getCommand();
                xQueueSendToBack(motorQueue, &toMotorQueue, portMAX_DELAY);                
            }
            
            // DEBUG
            dbgOutputLoc(AFTER_DATA_EQUALS_IF);
            
            OC1RS = appData.heartbeatCount;
            appData.ADCcount += 1;
            char potValue = 'x';
            potValue = PLIB_ADC_ResultGetByIndex(ADC_ID_1,appData.ADCcount);
            appData.ADCToggle = !appData.ADCToggle;
            OC1RS = (int) appData.ADCToggle;
            if(prevMotor != toMotor)
            {
                // DEBUG
                dbgOutputLoc(ENTERED_PREV_NOT_EQUALS_MOTOR);
                
                if(toMotor == MOTOR_STOP)
                    Move = stop;
                else if(toMotor == MOTOR_RIGHT)
                    Move = right; 
                else if(toMotor == MOTOR_FORWARD)
                    Move = forward;
                else if(toMotor == MOTOR_BACKWARD)
                    Move = backward;
                else if(toMotor == MOTOR_LEFT)
                    Move = left;
                else if(toMotor == SERVER_PING)
                {
                    sendPingMessage("PONG", 4, transmitQueue);
                    //Move = forward;
                }
                else if(toMotor == MODE_GAME)
                {
                    sendModeMessage("GAME", 4, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == MODE_DEBUG)
                {
                    sendModeMessage("DEBUG", 5, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == MODE_TEST)
                {
                    sendModeMessage("TEST", 4, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == MODE_CALIBRATE)
                {
                    sendModeMessage("CALIBRATE", 9, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == TEST_SPI)
                {
                    uint8_t spiCases;
                    
                    sendTestMessage("SPI", 3, transmitQueue);
                    spiCases = testCaseOneSpi();
                    sendTestValMessage(spiCases, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == TEST_RFID_ID)
                {
                    sendTestMessage("RFID_ID", 7, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == TEST_RFID_RANGE)
                {
                    sendTestMessage("RFID_RANGE", 10, transmitQueue);
                    Move = stop;
                }
                else if(toMotor == TEST_RFID_INTER)
                {
                    sendTestMessage("RFID_INTER", 10, transmitQueue);
                    Move = stop;
                }
                
            switch(Move)
            {
                // DEBUG
                dbgOutputLoc(ENTERED_MOTOR_SWITCH);
                
                case backward:
                {
                    //sendDirMessage("BACKWARD", 8, transmitQueue);
                    Motor_Backward();
                    break;
                }
                case forward:
                {
                    //sendDirMessage("FORWARD", 7, transmitQueue);
                    Motor_Forward();
                    break;
                }
                case right:
                {
                    //sendDirMessage("RIGHT", 5, transmitQueue);
                    Motor_Right();
                    break;
                }
                case left:
                {
                    //sendDirMessage("LEFT", 4, transmitQueue);
                    Motor_Left();
                    break;
                }
                case stop:
                {
                    //sendDirMessage("STOP", 4, transmitQueue);
                    Motor_Stop();
                    break;
                }
                default:
                {
                    //sendErrorMessage("DEFAULT", 7);
                    Motor_Stop();
                    break;
                }
            }
            prevMotor = toMotor;
            }
            break;
        }
        case APP_STATE_SERVICE_TASKS:
        {
            /*switch(SPI_State)
            {
                int i;
                
                case SEND_WRITE_CMD:
                    TXbuffer[0] = 0x44;
                    
                    Write_Buffer_Handle = DRV_SPI_BufferAddWrite(SPIHandle, TXbuffer, 1, 0, 0);
                    
                    // DEBUG
                    dbgOutputLoc(CASE_SEND_READ_CMD);
                    
                    if(Write_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
                    {
                        SPI_State = WAIT_FOR_REPLY;
                    }
                    
                    break;
                case WAIT_FOR_REPLY:
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_REPLY);
                    
                    if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus( Write_Buffer_Handle ) )
                    {
                        SPI_State = SEND_DATA;
                        //SPI_State = GET_DATA;
                    }
                    break;
                case SEND_DATA:
                    for(i = 0; i < 64; ++i)
                        TXbuffer[i] = 0x01;
                    
                    Write_Buffer_Handle = DRV_SPI_BufferAddWrite(SPIHandle, TXbuffer, 64, 0, 0);
                    
                    // DEBUG
                    dbgOutputLoc(CASE_SEND_READ_CMD);
                    
                    if(Write_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
                    {
                        SPI_State = WAIT_FOR_SEND;
                    }
                    break;
                case WAIT_FOR_SEND:
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_REPLY);
                    
                    if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus( Write_Buffer_Handle ) )
                    {
                        SPI_State = SEND_READ_CMD;
                    }
                    break;
                case SEND_READ_CMD:
                    TXbuffer[0] = 0xA4;
                    //TXbuffer[0] = 0x80;
                    //TXbuffer[0] = 0x92;
                    //TXbuffer[0] = 0xA8;
                    
                    Write_Buffer_Handle = DRV_SPI_BufferAddWrite(SPIHandle, TXbuffer, 1, 0, 0);
                    
                    // DEBUG
                    dbgOutputLoc(CASE_SEND_READ_CMD);
                    
                    if(Write_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
                    {
                        SPI_State = WAIT_FOR_REPLY_2;
                    }
                    
                    break;
                case WAIT_FOR_REPLY_2:
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_REPLY);
                    
                    if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus( Write_Buffer_Handle ) )
                    {
                        SPI_State = GET_DATA;
                    }
                    
                    break;
                case GET_DATA:
                    // DEBUG
                    dbgOutputLoc(CASE_GET_DATA);
                    
                    SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_G, 9 ); //(active low)
                    
                    Read_Buffer_Handle = DRV_SPI_BufferAddRead( SPIHandle, RXbuffer, 64, 0, 0);
                    if(Read_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
                    {
                        SPI_State = WAIT_FOR_DATA;
                    }
                    break;
                case WAIT_FOR_DATA:
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_DATA);
                    
                    if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus(Read_Buffer_Handle))
                    {
                        SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_G, 9 ); //(active low)
                        SPI_State = READ_COMPLETE;
                    }
                    myCount = 0;
                    break;
                case READ_COMPLETE:
                    // DEBUG
                    dbgOutputLoc(CASE_READ_COMPLETE);
                    
                    char Error_Message[] = "Received data over SPI does not match transmitted data";
                    if(myCount == 0)
                    {
                        if(RXbuffer[0] != 1)
                            sendErrorMessage("Received data over SPI does not match transmitted data", sizeof(Error_Message));
                    }
                    myCount++;
                    //SPI_State = SEND_READ_CMD;
                    break;
                default:
                    break;
            }*/
            break;
        }
        case TEST_SPI_BUS:
        {
            switch(SPI_State)
            {
                case SEND_WRITE_CMD:
                    SPI_States_Hit++;
                    
                    // DEBUG
                    dbgOutputLoc(SPI_States_Hit);
                    
                    
                    TXbuffer[0] = 0x01;
                    TXbuffer[1] = 0x02;
                    TXbuffer[2] = 0x03;
                    TXbuffer[3] = 0x04;
                    TXbuffer[4] = 0x05;
                    
                    Write_Buffer_Handle = DRV_SPI_BufferAddWrite(SPIHandle, TXbuffer, 5, 0, 0);
                    
                    // DEBUG
                    dbgOutputLoc(CASE_SEND_READ_CMD);
                    
                    if(Write_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
                    {
                        SPI_State = WAIT_FOR_REPLY;
                    }
                    
                    break;
                case WAIT_FOR_REPLY:
                    SPI_States_Hit++;
                    
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_REPLY);
                    
                    if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus( Write_Buffer_Handle ) )
                    {
                        SPI_State = GET_DATA;
                    }
                    break;
                case GET_DATA:
                    SPI_States_Hit++;
                    
                    // DEBUG
                    dbgOutputLoc(CASE_GET_DATA);
                    
                    Read_Buffer_Handle = DRV_SPI_BufferAddRead( SPIHandle, RXbuffer, 5, 0, 0);
                    if(Read_Buffer_Handle != DRV_SPI_BUFFER_HANDLE_INVALID )
                    {
                        SPI_State = WAIT_FOR_DATA;
                    }
                    break;
                case WAIT_FOR_DATA:
                    SPI_States_Hit++;
                    
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_DATA);
                    
                    if(DRV_SPI_BUFFER_EVENT_COMPLETE & DRV_SPI_BufferStatus(Read_Buffer_Handle))
                    {
                        SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_G, 9 ); //(active low)
                        SPI_State = READ_COMPLETE;
                    }
                    break;
                case READ_COMPLETE:
                    SPI_States_Hit++;
                    
                    // DEBUG
                    dbgOutputLoc(CASE_WAIT_FOR_DATA);
                    
                    if(SPI_States_Hit == SPI_STATES_HIT)
                    {
                        sendMessage("Test Case 1: SPI_States_Hit == 5", 32);
                    }
                    else
                    {
                        sendErrorMessage("Test Case 1: SPI_States_Hit != 5", 32);
                    }
                    
                    SPI_States_Hit = 0;
                    
                    SPI_State = SEND_WRITE_CMD;
                    break;
                default:
                    break;
            }
            break;
        }
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }  
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Interrupt Service Routines
// *****************************************************************************
// *****************************************************************************
// This ISR goes off every 3ms
void __ISR(_TIMER_2_VECTOR, ipl6auto) _IntHandlerDrvTmrInstance0( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2) )
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_ENTERED);
    
        count_timer_2++;
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
        
        // DEBUG
        //dbgOutputLoc(count_timer_2);
        
        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// This ISR goes off every 1.5ms
void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3) )
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_3_ENTERED);
        
        count_timer_3++;

        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);

        // DEBUG
        //dbgOutputLoc(count_timer_3);
        
        // DEBUG
        dbgOutputLoc(ISR_TIMER_3_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// This ISR goes off every 0.75ms
void __ISR(_TIMER_4_VECTOR, ipl5auto) _IntHandlerDrvTmrInstance2( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4) )
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_4_ENTERED);
    
        count_timer_4++;
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
        
        // DEBUG
        //dbgOutputLoc(count_timer_4);
        
        // DEBUG
        dbgOutputLoc(ISR_TIMER_4_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// This ISR goes off every 0.3ms
void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_5_ENTERED);
        
        count_timer_5++;

        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);

        // DEBUG
        //dbgOutputLoc(count_timer_5);
        
        // DEBUG
        dbgOutputLoc(ISR_TIMER_5_EXIT);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

void __ISR(_SPI_2_VECTOR, ipl7auto) _IntHandlerSPIInstance0( void )
{
    // DEBUG
    dbgOutputLoc(ENTER_SPI_INTERRUPT);
        
    DRV_SPI_Tasks(sysObj.spiObjectIdx0);
    
    // DEBUG
    dbgOutputLoc(EXIT_SPI_INTERRUPT);
}