/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************


//TO DO:  then check wifly wokr, then make message queue implementation, then interrupts
#include "app.h"
#include "FreeRTOS.h"
#include <stdio.h>
#include "task.h"
#include "timers.h"
#include "queue.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;
QueueHandle_t motorQueue = 0;
int count = 0;
int count2 = 0;
int count3 = 0;
int count4 = 0;
typedef enum {forward, backward, left, right, stop} MOVEMENT;
MOVEMENT Move;
//QueueHandle_t queue2 = 0;
//const void * to_send;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary local functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    TRISD = 0xFFDC;//TRISD0 is for motor 1 PWM
                   //TRISD1 is for motor 2 PWM
                   //TRISD5 is for motor 2 direction, 0 forward 1 backward
    TRISF = 0x313D;//TRISF1 is for motor 1 direction
    
    DRV_ADC_Open();
    DRV_ADC_Start();
  
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;
    appData.heartbeatTimer = DRV_HANDLE_INVALID;
    appData.heartbeatCount = 0;
    appData.heartbeatToggle = false;
    appData.ADCToggle = false;
    appData.ADCcount = 0;
    Move = stop;
    motorQueue = xQueueCreate(10, sizeof(unsigned int));
    //queue2 = xQueueCreate(30, sizeof(unsigned int));
}

static void APP_TimerCallback ( uintptr_t context, uint32_t alarmCount )
{
 //DRV_USART0_WriteByte('i');
 int to_send;
 BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
 appData.heartbeatCount++;
 if (appData.heartbeatCount >= APP_HEARTBEAT_COUNT_MAX)
 {
 appData.heartbeatCount = 0;
 appData.heartbeatToggle = true;
 }
 to_send = appData.heartbeatCount;
 count = count + 1;
 if(count == 99)
 {
     count = 0;
     count2 = count2 + 1;
 }
 //xQueueSendToBackFromISR(motorQueue, &to_send, &pxHigherPriorityTaskWoken);
 portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
char prevMotor = '0';
char toMotor = '0';
char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;
//if uart has data received. THIS SHOULD BE MOVE TO THE INTERRUPT
    
    if (appData.heartbeatToggle == true)
    {
        SYS_PORTS_PinToggle(PORTS_ID_0, APP_HEARTBEAT_PORT,
        APP_HEARTBEAT_PIN);
        appData.heartbeatToggle = false;
    }

    switch ( appData.state )
    {
        case APP_STATE_INIT:
        {
            appData.heartbeatTimer = DRV_TMR_Open( APP_HEARTBEAT_TMR,
            DRV_IO_INTENT_EXCLUSIVE);
            if ( DRV_HANDLE_INVALID != appData.heartbeatTimer )
            {
                DRV_TMR_AlarmRegister(appData.heartbeatTimer,
                APP_HEARTBEAT_TMR_PERIOD,
                APP_HEARTBEAT_TMR_IS_PERIODIC,
                (uintptr_t)&appData,
                APP_TimerCallback);
                DRV_TMR_Start(appData.heartbeatTimer);
                appData.state = APP_STATE_IDLE;
            }
            break;
         }
        case APP_STATE_IDLE:
        {
            //DRV_USART0_WriteByte('i');
            if(!DRV_USART0_ReceiverBufferIsEmpty()){
                data = DRV_USART0_ReadByte();
                if (data != '0')
                    xQueueSendToBack(motorQueue, &data, portMAX_DELAY);
            }
            if(!xQueueIsQueueEmptyFromISR(motorQueue))
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            
            //then xQreceive
            /////xQueueReceive(queue2, pvBuffer, portMAX_DELAY); no nneed
            /////xQueueSendToBack(motorQueue, pvBuffer2, portMAX_DELAY);
            //xQueueReceive(motorQueue, &pvBuffer, portMAX_DELAY);
            OC1RS = appData.heartbeatCount;
            //DRV_USART0_WriteByte(pvBuffer);
            appData.ADCcount += 1;
            char potValue = 'x';
            potValue = PLIB_ADC_ResultGetByIndex(ADC_ID_1,appData.ADCcount);
            //DRV_USART0_WriteByte(potValue);
            appData.ADCToggle = !appData.ADCToggle;
            OC1RS = (int) appData.ADCToggle;
            if(prevMotor != toMotor){
                if(toMotor =='s')
                    Move = stop;
                else if(toMotor == 'r')
                    Move = right; 
                else if(toMotor == 'f')
                    Move = forward;
                else if(toMotor == 'b')
                    Move = backward;
                else if(toMotor == 'l')
                    Move = left;
                DRV_USART0_WriteByte(toMotor);
            
            switch(Move){
                case forward:
                {
                    LATD = 0x0003;//forward
                    LATF = 0x0000;
                    break;
                }
                case backward:
                {
                    LATD = 0x0023;//reverse
                    LATF = 0x0001;//reverse
                    break;
                }
                case right:
                {
                    LATD = 0x0003;
                    LATF = 0x0001;
                    break;
                }
                case left:
                {
                    LATD = 0x0023;//right meaning left motor forward right motor backward
                    LATF = 0x0000;
                    break;
                }
                case stop:
                {
                    LATD = 0x0000; ///move to ISR, no need for state machine.
                    LATF = 0x0000;
                    break;
                }
                default:
                {
                    LATD = 0x0000;
                    LATF = 0x0000;
                    break;
                }
            }
            prevMotor = toMotor;
            }
            break;
        }
        case APP_STATE_SERVICE_TASKS:
        {
            break;
        }
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
    /*
    switch(toMotor){
        case 'f':
            LATD = 0x0003;//forward
            LATF = 0x0000;
            break;
        case 'b':
            LATD = 0x0023;//reverse
            LATF = 0x0001;//reverse
            break;
        case 'r':
            LATD = 0x0003;
            LATF = 0x0001;
            break;
        case 'l':
            LATD = 0x0023;//right meaning left motor forward right motor backward
            LATF = 0x0000;
            break;
        case 's':
            LATD = 0x0000; ///move to ISR, no need for state meachine.
            LATF = 0x0000;
            break;
        default:
            LATD = 0x0000; ///move to ISR, no need for state meachine.
            LATF = 0x0000;
            break;
    }
     */
    
}


