#include "FreeRTOS.h"
#include "app.h"
#include "jsonparser.h"
#include "motor.h"

int needToStop = 1;
int needToTurn = 0;
int needToClear = 1;

int16_t RIGHT_PULSE_WIDTH = 1100;
int16_t LEFT_PULSE_WIDTH = 1100;

uint32_t timerThreeVal;
uint32_t timerFourVal;

// HEADING defined in app.h
HEADING initialFacing = EAST;
HEADING currentFacing = EAST;
HEADING needToFace = EAST;

int degreesToTurn = 0;

int curColumnPos;
int curRowPos;

//returns true if the sensor array reads all black
bool isHit()
{
	return false; //TODO: update with sensor array readings
}

// pass in currentFacing for current
int calculateTurn (HEADING current, HEADING next)
{
    if(current == next)
    {
        return 0;
    }
    else if ((current + next) % 2 == 0)
    {
        return 180;
    }
    else if ((current == (next + 1) % 4))
    {
        // for this case, perform a left turn of 90 degrees instead.
        return -90;
    }
    else
    {
        return 90;
    }
}

void navigateToX(int curX, int goX)
{
    if (curX == goX)
    {
        // already in the correct row.
        degreesToTurn = 0;
        needToFace = currentFacing;
        
        /*
         * TODO: Use the reflectance sensor to determine the number of squares we have crossed (black stripe count).
         * TODO: Keep moving until we are in the right x-coordinate.
         */

        return;
    }
    else
    {
        // Determine if we need to do a left or right turn.
        if (curX > goX)
        {
            // need to face WEST.
            degreesToTurn = calculateTurn(currentFacing, WEST);
            needToFace = WEST;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
        else
        {
            // need to face EAST.
            degreesToTurn = calculateTurn(currentFacing, EAST);
            needToFace = EAST;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
    }
}

void navigateToY(int curY, int goY)
{
    if (curY == goY)
    {
        // already in the correct column.
        degreesToTurn = 0;
        needToFace = currentFacing;

        /*
         * TODO: Use the reflectance sensor to determine the number of squares we have crossed (black stripe count).
         * TODO: Keep moving until we are in the right y-coordinate.
         */
        
        return;
    }
    else
    {
        // Determine if we need to do a left or right turn.
        if (curY > goY)
        {
            // need to face NORTH.
            degreesToTurn = calculateTurn(currentFacing, NORTH);
            needToFace = NORTH;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
        else
        {
            // need to face SOUTH.
            degreesToTurn = calculateTurn(currentFacing, SOUTH);
            needToFace = SOUTH;
            // use this variable inside the timer 2 ISR.
            // update the current heading inside the timer 2 ISR.
            
            if (degreesToTurn == -90)
            {
                // do a left turn of 90 degrees.
                toMotor = MOTOR_LEFT;
            }
            else
            {
                // do a right turn of degreesToTurn
                toMotor = MOTOR_RIGHT;
            }
        }
    }
}

void navigateToCoordinate(int curX, int curY, int goX, int goY)
{
    navigateToX(curX, goX);
    navigateToY(curY, goY);
    
    /*
     * TODO: Once you get to the correct x and y coordinate, check for a hit.
     */
}

void getCommand(char *cmd, value *cmdType)
{
    parse(receiveQueue, cmd, cmdType);
    //DRV_USART0_WriteByte('9');
    //DRV_USART0_WriteByte(cmd);
    //DRV_USART0_WriteByte(temp);
    return;
};

bool goToCoordinate(char cmd)
{
    
    /*

     * Get the rover's current coordinates.
     * Get the rover's current "direction" aka which way it's facing.
     * Calculate how far we need to go vertically.
     * Calculate how far we need to go horizontally.
     * Use the reflectance sensor to determine the number of squares we have crossed (black stripe count).
     * Keep moving until we get to the desired coordinate.
     
     */
    int row = cmd & 0xF;
    int column = (cmd >> 4) - 3;
    char output[] = {row, ',', column};
    bool hit = false;
    
    //TODO: flag the motors to start moving
    //TODO: flag hit / miss logic
    
    /*
    if (hit || row == 0x32)
    {
        sendGeneralMessage("hit", 3, output, 3, transmitQueue);    
        return true;
    }
    else
    {
        sendGeneralMessage("miss", 4, output, 3, transmitQueue);    
    }
    */

    return hit;
}

void getDistanceReading() 
{
    SYS_PORTS_Write( PORTS_ID_0, PORT_CHANNEL_A, (1 << 8) << 8);
    int distance = 0;
    char returnValue = 0x0;
    SYS_PORTS_Write( PORTS_ID_0, PORT_CHANNEL_A, 0x0 << 8);
    while (distance < 350) 
    {
        distance++;
    }

    readPort(&returnValue);
    while (returnValue < 0x200 && distance < 10000) 
    {
        readPort(&returnValue);
        distance++;
    }
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    distance = distance / 10;
    //DRV_USART0_WriteByte((distance % 10) + 0x30);    
    char *x;
   // int size = asprintf(&x, "%i", distance);
   // DRV_USART0_WriteByte('o');    
   // if(size == -1){
   //     sendErrorMessage("distance", 8);
   // }
   // else{
        sendGeneralMessage("distance", 8, "far", 3, transmitQueue);
   // }
   // free(x);
}

void APP_Initialize ( void )
{
    // Initialize ports for the motor control
    Motor_Init();
  
    lastSentMessage[0] = '\0';
    appData.clientName = DEFAULT_NAME;
    appData.clientMode = DEBUG;
    appData.isActiveClient = false;
    appData.state = APP_STATE_INIT;
    /* Place the App state machine in its initial state. */
    appData.hits_to_win = 3;
    // Initial state for motor state machine 
    Move = stop;
    
    // Initialize queues
    motorQueue = xQueueCreate(30, sizeof(unsigned int));
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    transmitQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    count_timer_5 = 0;
    count = 0;
    count2 = 0;
    count3 = 0;
    sense = 0;
    c = 0;
    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('N');    
    DRV_USART0_WriteByte('I');    
    DRV_USART0_WriteByte('T');    
    // Gives a starting point in DigiView
    dbgOutputLoc(0xFF);
    
    SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_A, 3 );
}

void APP_Tasks ( void ){
    char prevMotor = '0';
    char prevCmd = '0';
    toMotor = '0';
    char toMotorQueue = '0';
    char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;

    switch ( appData.state ){
        case APP_STATE_INIT:{            
        
            // START TIMER 2
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
            DRV_TMR0_Start();
            // TIMER 2
            
            // START TIMER 3
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
            DRV_TMR1_Start();
            // TIMER 3
            
            // START TIMER 4
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
            DRV_TMR2_Start();
            // TIMER 4
            
            // START TIMER 5
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_5);
            DRV_TMR3_Start();
            // TIMER 5
                        
            DRV_USART0_WriteByte('I');    
            DRV_USART0_WriteByte('D');    
            DRV_USART0_WriteByte('L');    
            DRV_USART0_WriteByte('E');    
            appData.state = APP_STATE_IDLE;
            appData.clientName = DEFAULT_NAME;
            appData.hits_to_win = 3;
            appData.isGameOver = false;
            appData.isWinner = false;
            
            break;
         }
        case APP_STATE_IDLE:
        {   
            //*********//This is just temporary for random sensing until game logic is  done
            if(sense) c=0;
            if(count2 > 10000){
                count3++;
                count2 = 0;
                if(count3 > 10){
                    count3 = 0;
                    sense = 1;
                }
            }
            else
                count2++;
            //*************//
            switch(SENSE)
            {
                case out:
                {
                    if(sense)
                    {
                        TRISE = 0x0300; //set pins RE0 to RE7 to 0: output
                        LATE = 0x00FF;
                        SENSE = in;
                        count = 0;
                        count_timer_5 = 0;
                    }
                    break;
                }
                case in:
                {
                    if(count_timer_5 > 1)
                    {
                        TRISE = 0x3FF; //set pins RE0 to RE7 to 1: input
                        LATE = 0x0000; //value sent to pins is zero, let them decay
                        if(PORTE & 0xFF)
                                count = count_timer_5;
                        else
                            SENSE = stopped;
                        //DRV_USART0_WriteByte(count);
                    }
                    break;
                }
                case stopped:
                {
                    if(count < 90)
                    { //white
                        //toMotor = MOTOR_BACKWARD;
                        if(c < 1)
                        {
                            DRV_USART0_WriteByte('W');
                        }
                        else
                            c++;
                    }
                    else 
                    {//black
                        //toMotor = MOTOR_LEFT;
                        if(c < 1)
                        {
                            DRV_USART0_WriteByte('B');
                        }
                        else
                            c++;
                    }
                    sense = 0;
                    SENSE = out;  
                    break;
                }
            }
            
            char cmd;
            value cmdType;
            if(!DRV_USART0_ReceiverBufferIsEmpty())
            {
                dbgOutputLoc(UART_RECEIVE_BUFFER_NOT_EMPTY);
                data = DRV_USART0_ReadByte();

                if(data == '{')
                {
                    charIsJunk = false;
                }
                if (!charIsJunk)
                {
                    xQueueSendToBack(receiveQueue, &data, portMAX_DELAY);
                }
                if (data == '}')
                {
                    charIsJunk = true;
                }
            }
            dbgOutputLoc(AFTER_UART_RECEIVE_BUFFER_NOT_EMPTY);
            
            //if the motor has a command to change, pop the char command to toMotor.
            if(!xQueueIsQueueEmptyFromISR(motorQueue)){
                dbgOutputLoc(MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            }
            dbgOutputLoc(AFTER_MOTOR_QUEUE_FROM_ISR_NOT_EMPTY);
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //if the JSON message is completed, parse it.
            if(data == '}')
            { //end of a JSON command
                dbgOutputLoc(ENTERED_DATA_EQUALS_IF);
                
                getCommand(&cmd, &cmdType);
                //if this is a motor command, ad a message to the motor queue
                if (cmdType == ACTIVE)
                {
                    if (cmd == appData.clientName) 
                    {
                        sendGeneralMessage("activated", 9, &appData.clientName, 1, transmitQueue);
                        appData.isActiveClient = true; 
                    }
                    else 
                    {
                        sendGeneralMessage("deact", 5, &appData.clientName, 1, transmitQueue);
                        appData.isActiveClient = false; 
                    }
                }
                else if (!appData.isActiveClient)
                {
                    //continue with what you were doing before.
           //         sendGeneralMessage("ghost",5,&appData.clientName,1,transmitQueue);
                }
                else if (cmdType == GAMEOVER || appData.isGameOver) 
                {
                    appData.isGameOver = true;
                    if (cmdType == GAMEOVER && cmd != appData.clientName)
                    {
                        appData.isWinner = false;
                    }
                    if(appData.isWinner)
                        sendGeneralMessage("WinScore",8,"3",1,transmitQueue);
                    else 
                    {
                        char score[1]= {((3 - appData.hits_to_win) & 0xF) + 0x30};
                        sendGeneralMessage("LossScore",9,score,1,transmitQueue);
                    }
                }
                else if (cmdType == PING)
                {
                    sendGeneralMessage("pong",4,&appData.clientName,1,transmitQueue);
                }
                else if (cmdType == DIRECTION) 
                {
                    toMotorQueue = cmd;
                    xQueueSendToBack(motorQueue, &toMotorQueue, portMAX_DELAY);                
                }
                else if (cmdType == BAD)
                {
                    sendGeneralMessage("error",5,"bad JSON",8,transmitQueue);
                }
                else if (cmdType == PING)
                {
                    sendGeneralMessage("ping",4,"pong",4,transmitQueue);
                }
                else if (cmdType == MODE)
                {
                    appData.clientMode = cmd;
                    sendGeneralMessage("mode",4,&cmd,1,transmitQueue);
                }
                else if (cmdType == SETNAME)
                {
                    appData.clientName = cmd;
                    sendGeneralMessage("setname",7,&cmd,1,transmitQueue);
                }
                else if (cmdType == DISTANCE)
                {
                    getDistanceReading();
                }
                else if (cmdType == GOTO)
                {
                    if (goToCoordinate(cmd)) 
                    {
                        appData.hits_to_win = appData.hits_to_win - 1;
                    }
                    if(appData.hits_to_win == 0) 
                    {
                        sendGeneralMessage("WIN",3,&appData.clientName,1,transmitQueue);
                        appData.isGameOver = true;
                        appData.isWinner = true;
                    }
                }
                else 
                {
                    sendGeneralMessage("error",5,"missing",7,transmitQueue);
                }
            }
            dbgOutputLoc(AFTER_DATA_EQUALS_IF);

            if (prevMotor != toMotor)
            {

                if (toMotor == MOTOR_STOP)
                {
                    needToStop = 1;
                    DRV_TMR1_CounterClear();
                    DRV_TMR2_CounterClear();
                }
                else
                {
                    needToStop = 0;
                }

                if (toMotor == MOTOR_RIGHT || toMotor == MOTOR_LEFT)
                {
                    needToTurn = 1;

                    if (needToClear == 1)
                    {
                        DRV_TMR1_CounterClear();
                        DRV_TMR2_CounterClear();

                        // 1250
                        // 1300

                        LEFT_PULSE_WIDTH = 1300;
                        RIGHT_PULSE_WIDTH = 1300;

                        DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                        DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);

                        needToClear = 0;
                    }
                }
                else if (toMotor == MOTOR_FORWARD || toMotor == MOTOR_BACKWARD)
                {
                    needToTurn = 0;
                    if (needToClear == 0)
                    {
                        DRV_TMR1_CounterClear();
                        DRV_TMR2_CounterClear();

                        LEFT_PULSE_WIDTH = 1100;
                        RIGHT_PULSE_WIDTH = 1100;
                        needToClear = 1;
                    }
                }
                dbgOutputLoc(ENTERED_PREV_NOT_EQUALS_MOTOR);
                //DRV_USART0_WriteByte(Move);

                changeDirection(toMotor);
                prevMotor = toMotor;
            }
        }
    }
}

//Timer2 is internal, period of 20us
void __ISR(_TIMER_2_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance0(void)
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2))
    {
        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_ENTERED);

        count_timer_2++;

        if (needToStop == 1)
        {
            DRV_OC0_PulseWidthSet(0);
            DRV_OC1_PulseWidthSet(0);
        }
        else
        {
            if (needToTurn == 0)
            {

                DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);

                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT

                if (timerThreeVal < timerFourVal)
                {
                    // the RIGHT motor is going faster. Speed up left motor.

                    float offset = timerFourVal - timerThreeVal;
                    LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH + (offset / timerThreeVal) * 100;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH - (offset / timerFourVal) * 100;

                }
                else if (timerThreeVal > timerFourVal)
                {
                    // the LEFT motor is going faster. Speed up right motor.

                    float offset = timerThreeVal - timerFourVal;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH + (offset / timerFourVal) * 200;

                }
            }
            else
            {
                // we want to turn.

                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT
                int leftStopped = 0;
                int rightStopped = 0;
                
                // 90 DEGREE TURN (RIGHT / LEFT)
                // 3
                // 4

                // 180 DEGREE TURN (LEFT)
                // 6
                // 6
                
                if (degreesToTurn == 90)
                {
                    // DO A RIGHT TURN OF 90 DEGREES.
                    if (timerThreeVal >= 3)
                    {
                        DRV_OC0_PulseWidthSet(0);
                        leftStopped = 1;
                    }
                    if (timerFourVal >= 4)
                    {
                        DRV_OC1_PulseWidthSet(0);
                        rightStopped = 1;
                    }
                    if (leftStopped == 1 && rightStopped == 1)
                    {
                        // turn has finished.
                        degreesToTurn = 0;
                        currentFacing = needToFace;
                    }
                }
                else if (degreesToTurn == 180)
                {
                    // DO A LEFT TURN OF 180 DEGREES.
                    if (timerThreeVal >= 6)
                    {
                        DRV_OC0_PulseWidthSet(0);
                        leftStopped = 1;
                    }
                    if (timerFourVal >= 6)
                    {
                        DRV_OC1_PulseWidthSet(0);
                        rightStopped = 1;
                    }
                    if (leftStopped == 1 && rightStopped == 1)
                    {
                        // turn has finished.
                        degreesToTurn = 0;
                        currentFacing = needToFace;
                    }
                }
                else if (degreesToTurn == -90)
                {
                    // DO A LEFT TURN OF 90 DEGREES.
                    if (timerThreeVal >= 3)
                    {
                        DRV_OC0_PulseWidthSet(0);
                        leftStopped = 1;
                    }
                    if (timerFourVal >= 4)
                    {
                        DRV_OC1_PulseWidthSet(0);
                        rightStopped = 1;
                    }
                    if (leftStopped == 1 && rightStopped == 1)
                    {
                        // turn has finished.
                        degreesToTurn = 0;
                        currentFacing = needToFace;
                    }
                }
            }
        }

        if (RIGHT_PULSE_WIDTH >= 1600 || LEFT_PULSE_WIDTH >= 1600)
        {
            // right = 1100;
            // left = 1200;
            RIGHT_PULSE_WIDTH = 1100;
            LEFT_PULSE_WIDTH = 1200;
        }

        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);

        // DEBUG
        dbgOutputLoc(count_timer_2);

        // DEBUG
        dbgOutputLoc(ISR_TIMER_2_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 3 is externally sourced, period of 1.6ms
void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3) )
    {
        dbgOutputLoc(ISR_TIMER_3_ENTERED);
        count_timer_3++;
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
        dbgOutputLoc(count_timer_3);
        dbgOutputLoc(ISR_TIMER_3_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

//Timer 4 is externally sourced, period of 1.6ms
void __ISR(_TIMER_4_VECTOR, ipl5auto) _IntHandlerDrvTmrInstance2( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4) )
    {
        dbgOutputLoc(ISR_TIMER_4_ENTERED);
        count_timer_4++;
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
        dbgOutputLoc(count_timer_4);
        dbgOutputLoc(ISR_TIMER_4_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 5 is internal, period of 10us
void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        dbgOutputLoc(ISR_TIMER_5_ENTERED);
        count_timer_5++;
        PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
        dbgOutputLoc(count_timer_5);
        dbgOutputLoc(ISR_TIMER_5_EXIT);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}