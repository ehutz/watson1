/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _MESSAGES_H    /* Guard against multiple inclusion */
#define _MESSAGES_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */
#include "FreeRTOS.h"
#include "queue.h"
#include "messages.h"
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Constants                                                         */
/* ************************************************************************** */
/* ************************************************************************** */

#define EXAMPLE_CONSTANT 0


// *****************************************************************************
// *****************************************************************************
// Section: Data Types
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
// *****************************************************************************
// Section: Interface Functions
// *****************************************************************************
// *****************************************************************************
char lastSentMessage[100];
void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue);
void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue);
void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue);
void sendGeneralMessage(char cmd[], unsigned int cmdLen,char msg[], 
        unsigned int msgLen, QueueHandle_t tQueue);
void sendErrorMessage(char out[], unsigned int length);
void sendUARTByte_WithSave(char msgChar, int pos);
void sendRepeatMessage();

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
