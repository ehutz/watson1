/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _JSONPARSER_H    /* Guard against multiple inclusion */
#define _JSONPARSER_H
#include "FreeRTOS.h"
#include "app.h"
#include "queue.h"
#include <stdbool.h>
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Constants                                                         */
/* ************************************************************************** */
/* ************************************************************************** */
    
// DIRECTION CONSTANTS
#define FORWARD 0x31    //1
#define BACKWARD 0x32   //2
#define LEFT 0x33       //3
#define RIGHT 0x34      //4
#define STOP 0x35       //5
    
// PING CONSTANTS
#define PONG 0x31       //1
    
// MODE CONSTANTS
#define GAME 0x31       //1
#define DEBUG 0x32      //2
#define TEST 0x33       //3
#define CALIBRATE 0x34  //4

    
// Mode constants
#define MAX_MESSAGE_LENGTH 25
#define BAD_MESSAGE 0x39 //9
    // *****************************************************************************
    // *****************************************************************************
    // Section: Data Types
    // *****************************************************************************
    // *****************************************************************************

enum {OPEN_CURLY, OPEN_QUOTE, KEY, COLON, VALUE, CLOSE_CURLY} state = OPEN_CURLY;
typedef enum {DIRECTION=0, MODE, PING, SETNAME, DISTANCE, BAD, ACTIVE, GOTO, GAMEOVER} value;
//    char parse(QueueHandle_t receiveQueue);
void parse(QueueHandle_t receiveQueue, char * cmd, value * cmdType);
void clearKey(char keyArray[]);
bool checkKeyMatch (char keyArray[], char matchArray[], int length);


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
