/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */
#include "messages.h"


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */



/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*******************************************************************************
  Function:
    void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendDirMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'd', 'i', 'r' ,'"', ':','"' };
    unsigned int header_length = 8;
    
    char footer[] = {'"', '}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        sendUARTByte_WithSave(header[i], i);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        sendUARTByte_WithSave(out[i], i + header_length);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        sendUARTByte_WithSave(footer[i], i + header_length + length);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendPingMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'p', 'i', 'n' ,'g','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        sendUARTByte_WithSave(header[i], i);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        sendUARTByte_WithSave(out[i], i + header_length);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        sendUARTByte_WithSave(footer[i], i + header_length + length);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendModeMessage(char out[], unsigned int length, QueueHandle_t tQueue)
{
    char header[] = { '{', '"', 'm', 'o', 'd' ,'e','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        sendUARTByte_WithSave(header[i], i);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        sendUARTByte_WithSave(out[i], i + header_length);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        sendUARTByte_WithSave(footer[i], i + header_length + length);            
        i=i+1;
    }
}

/*******************************************************************************
  Function:
    void sendErrorMessage(char out[], unsigned int length, QueueHandle_t tQueue)
 */
void sendErrorMessage(char out[], unsigned int length)
{
    char header[] = { '{', '"', 'E', 'R', 'R' ,'O','R','"', ':','"' };
    unsigned int header_length = 9;
    
    char footer[] = { '"','}'};
    unsigned int footer_length = 2;
    
    unsigned int i = 0;
    while (i < header_length)
    {
        sendUARTByte_WithSave(header[i], i);            
        i=i+1;
    }
    
    i = 0;
    while (i < length)
    {
        sendUARTByte_WithSave(out[i], i + header_length);            
        i=i+1;
    }
    
    i = 0;
    while (i < footer_length)
    {
        sendUARTByte_WithSave(footer[i], i + header_length + length);            
        i=i+1;
    }
}

void sendGeneralMessage(char cmd[], unsigned int cmdLen,char msg[], 
        unsigned int msgLen, QueueHandle_t tQueue){
    int count = 0;
    sendUARTByte_WithSave('{', count);            
    count++;
    sendUARTByte_WithSave('"', count);            
    int i = 0;
    while (i < cmdLen)
    {
        count++;
        sendUARTByte_WithSave(cmd[i], count);            
        i++;
    }
    count++;
    sendUARTByte_WithSave('"', count);            
    count++;
    sendUARTByte_WithSave(':', count);            
    count++;
    sendUARTByte_WithSave('"', count);            
    
    i = 0;
    while (i < msgLen)
    {
        count++;
        sendUARTByte_WithSave(msg[i], count);            
        i++;
    }
    count++;
    sendUARTByte_WithSave('"', count);            
    count++;
    sendUARTByte_WithSave('}', count);            
    
}
void sendUARTByte_WithSave(char msgChar, int pos) {
    if (pos < 100) {
        lastSentMessage[pos] = msgChar;
    }
    if (pos < 99){
        lastSentMessage[pos + 1] = '\0';
    }
    DRV_USART0_WriteByte(msgChar);            
}
void sendRepeatMessage(){
    int i = 0;
    char temp = lastSentMessage[0]; 
    while (i < 100 && temp != '\0')
    {
        DRV_USART0_WriteByte(lastSentMessage[i]);            
        i++;
    }

}

/* *****************************************************************************
 End of File
 */
