//this one is madelyn's being used for integration
#include "FreeRTOS.h"
#include "app.h"
#include "jsonparser.h"
#include "motor.h"

int needToStop = 1;
int needToTurn = 0;
int needToClear = 1;

int16_t RIGHT_PULSE_WIDTH = 1000;
int16_t LEFT_PULSE_WIDTH = 1100;

int16_t leftEncoderVal = 0;
int16_t rightEncoderVal = 0;

uint32_t timerThreeVal;
uint32_t timerFourVal;

void getCommand(char *cmd, value *cmdType) {
    parse(receiveQueue, cmd, cmdType);
    //DRV_USART0_WriteByte(temp);
    return;
};

void APP_Initialize(void) 
{
    appData.state = APP_STATE_INIT;

    // Initialize ports for the motor control
    Motor_Init();
    // Initial state for motor state machine 
    Move = stop;

    // Initialize queues
    motorQueue = xQueueCreate(30, sizeof (unsigned int));
    receiveQueue = xQueueCreate(30, sizeof (unsigned int));
    transmitQueue = xQueueCreate(30, sizeof (unsigned int));

    charIsJunk = true;
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    count_timer_5 = 0;
    count = 0;
    count2 = 0;
    count3 = 0;
    sense = 0;
    c = 0;
    
    // Start: Initialize ultrasonic sensor variables
    count_ultrasonic = 0;
    US_distance = 0;
    pulse_start = 0;
    pulse_end = 0;
    flag = false;
    echo_done = false;
    // End: Initialize ultrasonic sensor variables

    DRV_USART0_WriteByte('I');
    DRV_USART0_WriteByte('N');
    DRV_USART0_WriteByte('I');
    DRV_USART0_WriteByte('T');

    // Set LED4
    SYS_PORTS_PinSet(PORTS_ID_0, PORT_CHANNEL_A, 3);
}

void APP_Tasks(void) {
    char prevMotor = '0';
    toMotor = '0';
    char toMotorQueue = '0';
    char data = '0'; ///must initialize the char to something otherwise it thinks it is an int;

    switch (appData.state) 
    {
        case APP_STATE_INIT:
        {
            // START TIMER 2
            //PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
            //PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
            DRV_TMR0_Start();
            // TIMER 2

            // START TIMER 3
            //PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
            //PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
            DRV_TMR1_Start();
            // TIMER 3

            // START TIMER 4
            //PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
            //PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
            DRV_TMR2_Start();
            // TIMER 4

            // START TIMER 5
            //PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
            //PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_5);
            DRV_TMR3_Start();
            // TIMER 5

            DRV_USART0_WriteByte('I');
            DRV_USART0_WriteByte('D');
            DRV_USART0_WriteByte('L');
            DRV_USART0_WriteByte('E');
            appData.state = APP_STATE_IDLE;

            break;
        }
        case APP_STATE_IDLE:
        {
            // Start: Sends distance from ultrasonic sensor to the server
            if(count_ultrasonic % 100000 <= 1)
            {
                if(US_distance <= 7*10) //7cm but *10 because i want a decimal place (matches code in ISR)
                    sendNumber(US_distance);
            }
            // End: Sends distance from ultrasonic sensor to the server
            
            //*********//This is just temporary for random sensing until game logic is  done
            if (sense) c = 0;
            if (count2 > 1000) {
                count3++;
                count2 = 0;
                if (count3 > 10) {
                    count3 = 0;
                    sense = 1;
                }
            } else
                count2++;
            switch (SENSE) {
                case out:
                {
                    if (sense) {
                        TRISE = 0x0300; //set pins RE0 to RE7 to 0: output
                        LATE = 0x00FF;
                        SENSE = in;
                        count = 0;
                        count_timer_5 = 0;
                    }
                    break;
                }
                case in:
                {
                    if (count_timer_5 > 1) {
                        TRISE = 0x3FF; //set pins RE0 to RE7 to 1: input
                        LATE = 0x0000; //value sent to pins is zero, let them decay
                        if (PORTE & 0xFF)
                            count = count_timer_5;
                        else
                            SENSE = stopped;
                        DRV_USART0_WriteByte(count);
                    }
                    break;
                }
                case stopped:
                {
                    if (count < 90) { //white
                        //toMotor = MOTOR_BACKWARD;
                        if (c < 1) {
                            DRV_USART0_WriteByte('W');
                        } else
                            c++;
                    } else {//black
                        //toMotor = MOTOR_LEFT;
                        if (c < 1) {
                            DRV_USART0_WriteByte('B');
                        } else
                            c++;
                    }
                    sense = 0;
                    SENSE = out;
                    break;
                }
            }

            if (!DRV_USART0_ReceiverBufferIsEmpty()) {
                data = DRV_USART0_ReadByte();
                //   DRV_USART0_WriteByte(data);
                if (data == '{') {
                    charIsJunk = false;
                }
                if (!charIsJunk) {
                    xQueueSendToBack(receiveQueue, &data, portMAX_DELAY);
                }
                if (data == '}') {
                    charIsJunk = true;
                }
            }

            //if the motor has a command to change, pop the char command to toMotor.
            if (!xQueueIsQueueEmptyFromISR(motorQueue)) {
                xQueueReceive(motorQueue, &toMotor, portMAX_DELAY);
            }

            //if the JSON message is completed, parse it.
            if (data == '}') { //end of a JSON command
                char cmd;
                value cmdType;
                getCommand(&cmd, &cmdType);
                //if this is a motor command, ad a message to the motor queue
                if (cmdType == DIRECTION) {
                    toMotorQueue = cmd;
                    xQueueSendToBack(motorQueue, &toMotorQueue, portMAX_DELAY);
                } else if (cmdType == BAD) {
                    sendGeneralMessage("error", 5, "bad JSON", 8, transmitQueue);
                } else if (cmdType == PING) {
                    sendGeneralMessage("ping", 4, "pong", 4, transmitQueue);
                } else if (cmdType == MODE) {
                    sendGeneralMessage("mode", 4, "set", 3, transmitQueue);
                } else {
                    sendGeneralMessage("error", 5, "missing", 7, transmitQueue);
                }
            }

            if (prevMotor != toMotor) {

                if (toMotor == MOTOR_STOP)
                {
                    needToStop = 1;
                }
                else
                {
                    needToStop = 0;
                }

                if (toMotor == MOTOR_RIGHT || toMotor == MOTOR_LEFT)
                {
                    needToTurn = 1;
                    
                    if (needToClear == 1)
                    {
                        DRV_TMR1_CounterClear();
                        DRV_TMR2_CounterClear();
                    
                        LEFT_PULSE_WIDTH = 1250;
                        RIGHT_PULSE_WIDTH = 1300;
                    
                        DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                        DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);
                        
                        needToClear = 0;
                    }

                }
                else if (toMotor == MOTOR_FORWARD || toMotor == MOTOR_BACKWARD)
                {
                    needToTurn = 0;
                    if (needToClear == 0)
                    {
                        DRV_TMR1_CounterClear();
                        DRV_TMR2_CounterClear();
                        
                        LEFT_PULSE_WIDTH = 1200;
                        RIGHT_PULSE_WIDTH = 1100;
                        needToClear = 1;
                    }

                }
                //DRV_USART0_WriteByte(Move);

                changeDirection(toMotor);
                prevMotor = toMotor;
            }
        }
    }
}

//Timer2 is internal, period of 20us

void __ISR(_TIMER_2_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance0(void) {
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_2)) 
    {
        count_timer_2++;

        if (needToStop == 1)
        {
            DRV_OC0_PulseWidthSet(0);
            DRV_OC1_PulseWidthSet(0);
        } 
        else
        {
            if (needToTurn == 0)
            {
                // OC0 SHOULD BE 1350.
                // OC1 SHOULD BE 1200.
                DRV_OC0_PulseWidthSet(LEFT_PULSE_WIDTH);
                DRV_OC1_PulseWidthSet(RIGHT_PULSE_WIDTH);

                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT

                if (timerThreeVal < timerFourVal) {
                    // the RIGHT motor is going faster. Speed up left motor.
                    // 1200
                    // 1500
                    //RIGHT_PULSE_WIDTH = 1500;
                    //LEFT_PULSE_WIDTH = 1000;

                    float offset = timerFourVal - timerThreeVal;
                    LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH + (offset / timerThreeVal) * 100;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH - (offset / timerFourVal) * 100;

                    //DRV_TMR1_CounterClear();
                    //DRV_TMR2_CounterClear();
                }
                else if (timerThreeVal > timerFourVal) {
                    // the LEFT motor is going faster. Speed up right motor.
                    //1400
                    //1250
                    //RIGHT_PULSE_WIDTH = 1000;
                    //LEFT_PULSE_WIDTH = 1500;

                    float offset = timerThreeVal - timerFourVal;
                    RIGHT_PULSE_WIDTH = RIGHT_PULSE_WIDTH + (offset / timerFourVal) * 200;
                    //LEFT_PULSE_WIDTH = LEFT_PULSE_WIDTH - (offset / timerThreeVal);

                }
            }
            else
            {
                timerThreeVal = DRV_TMR1_CounterValueGet(); // LEFT
                timerFourVal = DRV_TMR2_CounterValueGet(); // RIGHT
                int leftStopped = 0;
                int rightStopped = 0;
                
                if (timerThreeVal >= 3)
                {
                    DRV_OC0_PulseWidthSet(0);
                    leftStopped = 1;
                }
                if (timerFourVal >= 4)
                {
                    DRV_OC1_PulseWidthSet(0);
                    rightStopped = 1;
                }
            }
        }
        
        if (RIGHT_PULSE_WIDTH >= 1600 || LEFT_PULSE_WIDTH >= 1600)
        {
            RIGHT_PULSE_WIDTH = 1200;
            LEFT_PULSE_WIDTH = 1200;
        }

        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_2);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 3 is externally sourced, period of 1.6ms

void __ISR(_TIMER_3_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance1(void) 
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_3)) 
    {
        count_timer_3++;
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_3);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

//Timer 4 is externally sourced, period of 1.6ms

void __ISR(_TIMER_4_VECTOR, ipl5auto) _IntHandlerDrvTmrInstance2(void) 
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_4)) 
    {
        count_timer_4++;
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_4);
    }
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

// Timer 5 is internal, period of 10us

void __ISR(_TIMER_5_VECTOR, ipl4auto) _IntHandlerDrvTmrInstance3(void) 
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    if (INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5)) 
    {
        count_timer_5++;
        
        // START: ULTRASONIC SENSOR LOGIC
        if(count_ultrasonic == 0)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 ); // Clear trigger
        }
        else if(count_ultrasonic == 1000000) // Wait 1 sec for trigger input to settle **MESS WITH THIS**
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_F, 0 );
        }
        else if(count_ultrasonic == 1000010) // wait 10us until set trig low **MESS WITH THIS**
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_F, 0 );
        }
        
        if(count_ultrasonic >= 1000010 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            pulse_start = count_ultrasonic-1000009;
        }
        if(count_ultrasonic >= 1000010 && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            flag = true;
            pulse_end = count_ultrasonic-1000009;
        }
        if(flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_F, 1))
        {
            echo_done = true;
        }
        
        count_ultrasonic++;
        
        if(echo_done)
        {
            US_distance = ((pulse_end - pulse_start) * 0.01715)*10*3; //3 is a magic number, *10 gives a decimal place
            echo_done = false; //reset
            count_ultrasonic = 0; //reset
            flag = false; //reset
        }
        // END: ULTRASONIC SENSOR LOGIC
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}
