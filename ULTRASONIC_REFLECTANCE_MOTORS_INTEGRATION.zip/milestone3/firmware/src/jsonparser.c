#include "jsonparser.h"

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */
/** Descriptive Data Item Name

  @Summary
    Brief one-line summary of the data item.
    
  @Description
    Full description, explaining the purpose and usage of data item.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
  @Remarks
    Any additional remarks
 */
int global_data;


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */

/** 
  @Function
    int ExampleLocalFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Description
    Full description, explaining the purpose and usage of the function.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

  @Precondition
    List and describe any required preconditions. If there are no preconditions,
    enter "None."

  @Parameters
    @param param1 Describe the first parameter to the function.
    
    @param param2 Describe the second parameter to the function.

  @Returns
    List (if feasible) and describe the return values of the function.
    <ul>
      <li>1   Indicates an error occurred
      <li>0   Indicates an error did not occur
    </ul>

  @Remarks
    Describe any special behavior not described above.
    <p>
    Any additional remarks.

  @Example
    @code
    if(ExampleFunctionName(1, 2) == 0)
    {
        return 3;
    }
 */
static int ExampleLocalFunction(int param1, int param2) {
    return 0;
}


/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    int ExampleInterfaceFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Remarks
    Refer to the example_file.h interface header for function usage details.
 */
char parse(QueueHandle_t rQueue) 
{
    char jsonChar = '0';
    char key[10];
    int i;
    char val = 's';
    
    clearKey(key);
    
    state = OPEN_CURLY;
    while(!xQueueIsQueueEmptyFromISR(rQueue))
    {
        xQueueReceive(rQueue, &jsonChar, portMAX_DELAY);
        if(jsonChar == '}')
        {
            return val;
        }
        switch(state)
        {
            case OPEN_CURLY:
                if(jsonChar == '{')
                {
                    state = OPEN_QUOTE;
                }
                break;
            case OPEN_QUOTE:
                if(jsonChar == '"')
                {
                    state = KEY;
                    i=0;
                }
                break;
            case KEY:
                if(jsonChar != '"' && i < 10)
                {
                    key[i] = jsonChar;
                    i++;
                }
                if(key[0] == 'd' && key[1] == 'i' && key[2] == 'r')
                {
                    value = DIRECTION;
                    state = COLON;
                }
                else if(key[0] == 'p' && key[1] == 'i' && key[2] == 'n' && key[3] == 'g')
                {
                    value = PING;
                    state = COLON;
                }
                else if(key[0] == 'm' && key[1] == 'o' && key[2] == 'd' && key[3] == 'e')
                {
                    value = MODE;
                    state = COLON;
                }
                else if(key[0] == 't' && key[1] == 'e' && key[2] == 's' && key[3] == 't')
                {
                    value = M3_TEST;
                    state = COLON;
                }
                
                break; 
            case COLON:
                if(jsonChar == ':')
                {
                    state = VALUE;
                }
                break;
            case VALUE: 
                switch(value)
                {
                    case DIRECTION:
                        if(jsonChar == STOP)
                        {
                            val = 's';
                        }
                        else if(jsonChar == FORWARD)
                        {
                            val = 'f';
                        }
                        else if(jsonChar == BACKWARD)
                        {
                            val = 'b';
                        }
                        else if(jsonChar == LEFT)
                        {
                            val = 'l';
                        }
                        else if(jsonChar == RIGHT)
                        {
                            val = 'r';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case PING:
                        if(jsonChar == PONG)
                        {
                            val = 'p';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case MODE:
                        if(jsonChar == GAME)
                        {
                            val = 'g';
                        }
                        else if(jsonChar == DEBUG)
                        {
                            val = 'd';
                        }
                        else if(jsonChar == TEST)
                        {
                            val = 't';
                        }
                        else if(jsonChar == CALIBRATE)
                        {
                            val = 'c';
                        }
                        state = CLOSE_CURLY;
                        
                        break;
                    case M3_TEST:
                        if(jsonChar == US_2)
                        {
                            val = 'w';
                        }
                        else if(jsonChar == US_10)
                        {
                            val = 'x';
                        }
                        else if(jsonChar == US_20)
                        {
                            val = 'y';
                        }
                        else if(jsonChar == US_100)
                        {
                            val = 'z';
                        }
                        state = CLOSE_CURLY;
                        break;
                    default:
                        break;
                }
                break;
            case CLOSE_CURLY:
                if(jsonChar == '}')
                {
                    return val;
                }
                break;
            default:
                // TODO: DEBUG - Print out character
                break;
        }
    }
}

void clearKey(char keyArray[])
{
    int i;
    for(i = 0; i < 10; i++)
    {
        keyArray[i] = NULL;
    }
}
/* *****************************************************************************
 End of File
 */
