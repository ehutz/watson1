/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************
#include "FreeRTOS.h"
#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )
 */

void APP_Initialize ( void )
{
    Motor_Init();
    Motor_Stop();
    
    DRV_USART0_WriteByte('X');
    
    appData.state = APP_STATE_INIT;
    
    receiveQueue = xQueueCreate(30, sizeof(unsigned int));
    ultrasonicQueue = xQueueCreate(30, sizeof(unsigned int));
    
    charIsJunk = true;
    
    count_timer_2 = 0;
    count_timer_3 = 0;
    count_timer_4 = 0;
    
    // START: Initializations for reflectance sensor in timer 5 ISR
    count_timer_5 = 0;
    blackCount = 0;
    count2 = 0;
    count3 = 0;
    c = 0;
    sense = 1;
    count = 0;
    SENSE = out;
    count_reflectance = 0;
    flag_reflectance = false;
    reflectance_pulse = 0;
    // END: Initializations for reflectance sensor in timer 5 ISR
            
    // START: Initializations for ultrasonic sensor in timer 5 ISR
    count_ultrasonic = 0;
    US_distance = 0;
    pulse_start = 0;
    pulse_end = 0;
    flag = false;
    echo_done = false;
    // END: Initializations for ultrasonic sensor in timer 5 ISR
}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
void APP_Tasks ( void )
{
    switch ( appData.state )
    {
        case APP_STATE_INIT:
        {
            DRV_USART0_WriteByte('Y');
            // START TIMERS 2,3,4,5
            //DRV_TMR0_Start();
            //DRV_TMR1_Start();
            //DRV_TMR2_Start();
            DRV_TMR3_Start();
            // TIMER 2,3,4,5
            
            appData.state = APP_STATE_IDLE;
           
            //appData.state = APP_STATE_SERVICE_TASKS;
            
            break;
         }
        case APP_STATE_IDLE:
        {
            //DRV_USART0_WriteByte('Z');
            if(US_distance <= 15*10 && US_distance != 0)
            {
                DRV_USART0_WriteByte('H');
                Motor_Stop();
                sendNumber(US_distance);
            }
            else if(US_distance > 15*10)
            {
                DRV_USART0_WriteByte('L');
                Motor_Backward();
                sendNumber(US_distance);
            }
            if(count_ultrasonic > 10)
                DRV_USART0_WriteByte('C');
            
            if(flag_reflectance)
            {
                if(count_reflectance-1 <= 8000)  //5000
                    DRV_USART0_WriteByte('W');
                else if(count_reflectance-1 >= 20000) //10000
                    DRV_USART0_WriteByte('B');
                flag_reflectance = false;
                count_reflectance = 0;
            }
            break;
        }
        case APP_STATE_SERVICE_TASKS:
        {
            /*char test_ultrasonic;
            uint32_t test_ultrasonic_2;
            
            if(!xQueueIsQueueEmptyFromISR(receiveQueue))
            {
                DRV_USART0_WriteByte('X'); // testing that code reaches this point
                xQueueReceive(receiveQueue, &test_ultrasonic, portMAX_DELAY);
                DRV_USART0_WriteByte(test_ultrasonic);
            }
            
            if(!xQueueIsQueueEmptyFromISR(ultrasonicQueue))
            {
                DRV_USART0_WriteByte('U'); // testing that code reaches this point
                xQueueReceive(ultrasonicQueue, &test_ultrasonic_2, portMAX_DELAY);
                DRV_USART0_WriteByte(test_ultrasonic_2);
            }*/
            break;
        }
        default:
        {
            break;
        }
    }  
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Interrupt Service Routines
// *****************************************************************************
// *****************************************************************************

// THIS ISR WORKS FOR ULTRASONIC SENSOR WITH PERIOD 100 (10 uS))
void __ISR(_TIMER_5_VECTOR, ipl7auto) _IntHandlerDrvTmrInstance3( void )
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    
    //count_timer_5++;
    
    if( INT_SourceFlagGet_Default(INT_ID_0, INT_SOURCE_TIMER_5) )
    {
        // START: Ultrasonic sensor logic
        /*if(count_ultrasonic == 0)
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_B, 13 ); // Clear trigger
        }
        else if(count_ultrasonic == 100000) // Wait 1 sec for trigger input to settle **MESS WITH THIS**
        {
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_B, 13 );
        }
        else if(count_ultrasonic == 100001) // wait 10us until set trig low **MESS WITH THIS**
        {
            SYS_PORTS_PinClear( PORTS_ID_0, PORT_CHANNEL_B, 13 );
        }
        
        if(count_ultrasonic >= 100001 && !flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_B, 12))
        {
            pulse_start = (count_ultrasonic*10)-100000;
        }
        if(count_ultrasonic >= 100001 && SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_B, 12))
        {
            flag = true;
            pulse_end = (count_ultrasonic*10)-100000;
        }
        if(flag && !SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_B, 12))
        {
            echo_done = true;
        }
        
        count_ultrasonic++;
        
        if(echo_done)
        {
            US_distance = ((pulse_end - pulse_start) * 0.01715);//*10; //*10 gives a decimal place
            echo_done = false; //reset
            count_ultrasonic = 0; //reset
            flag = false; //reset
        }*/
        // END: Ultrasonic sensor logic
        
        // START: Reflectance sensor logic
        if(count_reflectance == 0)
        {
            //TRISE = 0xFF00; // Set each sensor on the reflectance sensor to an output
            TRISE = 0xFF7F; // Set sensor 8 on the reflectance sensor to an output
            SYS_PORTS_PinSet( PORTS_ID_0, PORT_CHANNEL_E, 7 );
        } 
        else if(count_reflectance == 1) // Wait 10us
        {
            TRISE = 0xFFFF; // Set sensor 8 on the reflectance sensor to an input
        }
        count_reflectance++;
        if(!SYS_PORTS_PinRead(PORTS_ID_0, PORT_CHANNEL_E, 7) & 0x1)
        //if(!SYS_PORTS_Read(PORTS_ID_0, PORT_CHANNEL_E) & 0xFF)
        {
            flag_reflectance = true;
        }
        // END: Reflectance sensor logic
        
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_TIMER_5);
    }
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}